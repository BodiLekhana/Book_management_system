import { Component, OnInit, ChangeDetectorRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { catchError, finalize, of, timeout } from 'rxjs';
import { BookService } from '../../../core/services/book.service';
import { BorrowService } from '../../../core/services/borrow.service';
import { NotificationService } from '../../../core/services/notification.service';
import { Book } from '../../../core/models/book.model';
import { LoadingComponent } from '../../../shared/loading/loading';

@Component({
  selector: 'app-user-books',
  standalone: true,
  imports: [CommonModule, FormsModule, LoadingComponent],
  template: `
    <div class="container-fluid p-4">
      <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
          <h2 class="fw-bold mb-1">Book Catalog</h2>
          <p class="text-secondary small mb-0">Browse and borrow available books from the library</p>
        </div>

        <div class="d-flex gap-2" style="max-width: 400px; width: 100%;">
          <div class="input-group">
            <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-secondary"></i></span>
            <input type="text" class="form-control border-start-0" placeholder="Search title or author..." [(ngModel)]="searchTerm" (ngModelChange)="applyFilter()">
          </div>
        </div>
      </div>

      <app-loading *ngIf="isLoading" message="Fetching books catalog..."></app-loading>

      <div *ngIf="!isLoading">
        <div *ngIf="loadError" class="alert alert-danger rounded-4">
          <i class="bi bi-exclamation-triangle me-2"></i>
          Unable to load the book catalog. Please refresh and try again.
        </div>
        <div *ngIf="filteredBooks.length === 0" class="text-center py-5 bg-white rounded-4 border">
          <i class="bi bi-inbox fs-1 text-secondary"></i>
          <p class="text-secondary mt-2">No books found matching your criteria.</p>
        </div>

        <div class="row g-4" *ngIf="filteredBooks.length > 0">
          <div class="col-12 col-md-6 col-lg-4 col-xl-3" *ngFor="let book of filteredBooks">
            <div class="card h-100 border-0 shadow-sm rounded-4 bg-white position-relative d-flex flex-column">
              <div class="card-body p-4 d-flex flex-column">
                <div class="d-flex justify-content-between align-items-start mb-2">
                  <span class="badge bg-secondary-subtle text-secondary text-uppercase px-2.5 py-1 rounded-pill small">{{ book.category }}</span>
                  <span class="badge" [ngClass]="book.quantity > 0 ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'">
                    {{ book.quantity > 0 ? book.quantity + ' Available' : 'Out of Stock' }}
                  </span>
                </div>

                <h5 class="fw-bold card-title text-dark mb-1">{{ book.title }}</h5>
                <p class="card-subtitle text-secondary small mb-3">by {{ book.author }}</p>

                <div class="mt-auto pt-3 border-top d-flex justify-content-between align-items-center">
                  <div>
                    <span class="text-secondary small d-block">Price</span>
                    <span class="fw-bold text-dark fs-5">₹{{ book.price }}</span>
                  </div>

                  <button
                    class="btn btn-primary rounded-3 px-3 py-1.5 font-weight-bold"
                    [disabled]="book.quantity <= 0 || borrowingId === book.id"
                    (click)="borrowBook(book)">
                    <span *ngIf="borrowingId !== book.id"><i class="bi bi-bookmark-plus me-1"></i> Borrow</span>
                    <span *ngIf="borrowingId === book.id" class="spinner-border spinner-border-sm"></span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class UserBooksComponent implements OnInit {
  private bookService = inject(BookService);
  private borrowService = inject(BorrowService);
  private notificationService = inject(NotificationService);
  private cdr = inject(ChangeDetectorRef);

  loadError = false;

  books: Book[] = [];
  filteredBooks: Book[] = [];
  isLoading = true;
  searchTerm = '';
  borrowingId: number | null = null;

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks(): void {
    this.isLoading = true;
    this.loadError = false;

    this.bookService.getAllBooks().pipe(
      timeout(10000),
      catchError(() => {
        this.books = [];
        this.filteredBooks = [];
        this.loadError = true;
        return of([] as Book[]);
      }),
      finalize(() => {
        this.isLoading = false;
        this.cdr.detectChanges();
      })
    ).subscribe({
      next: (data) => {
        this.books = Array.isArray(data) ? data : [];
        this.applyFilter();
        this.cdr.detectChanges();
      }
    });
  }

  applyFilter(): void {
    if (!this.searchTerm.trim()) {
      this.filteredBooks = [...this.books];
      return;
    }
    const term = this.searchTerm.toLowerCase();
    this.filteredBooks = this.books.filter(b =>
      b.title.toLowerCase().includes(term) ||
      b.author.toLowerCase().includes(term) ||
      b.category.toLowerCase().includes(term)
    );
  }

  borrowBook(book: Book): void {
    if (!book.id) return;
    this.borrowingId = book.id;

    this.borrowService.borrowBook(book.id).pipe(
      finalize(() => {
        this.borrowingId = null;
      })
    ).subscribe({
      next: () => {
        this.notificationService.showSuccess(`Successfully borrowed "${book.title}"!`);
        this.loadBooks();
      },
      error: () => {}
    });
  }
}

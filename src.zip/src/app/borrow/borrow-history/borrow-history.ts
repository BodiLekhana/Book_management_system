import { Component, OnInit } from '@angular/core';
import { BorrowService } from '../../core/services/borrow.service';
import { Borrow } from '../../core/models/borrow.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-borrow-history',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './borrow-history.html',
  styleUrls: ['./borrow-history.css']
})
export class BorrowHistoryComponent implements OnInit {

  records: Borrow[] = [];

  constructor(private service: BorrowService) {}

  ngOnInit(): void {
    this.service.getAllBorrows()
      .subscribe(data => this.records = data);
  }
}
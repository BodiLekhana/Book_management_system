import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BorrowService } from '../../core/services/borrow.service';
import { Borrow } from '../../core/models/borrow.model';

@Component({
  selector: 'app-my-borrows',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-borrows.html',
  styleUrls: ['./my-borrows.css']
})
export class MyBorrowsComponent implements OnInit {

  borrows: Borrow[] = [];

  constructor(private borrowService: BorrowService) {}

  ngOnInit(): void {
    this.loadBorrows();
  }

  loadBorrows() {
    this.borrowService.getMyBorrows()
      .subscribe({
        next: (data) => this.borrows = data,
        error: console.error
      });
  }

  returnBook(id: number) {
    this.borrowService.returnBook(id)
      .subscribe(() => {
        alert('Book Returned Successfully');
        this.loadBorrows();
      });
  }
}
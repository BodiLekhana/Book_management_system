import { Routes } from '@angular/router';

import { LoginComponent } from './auth/login/login';

import { UserDashboardComponent }
from './dashboard/user-dashboard/user-dashboard';

import { AdminDashboardComponent }
from './dashboard/admin-dashboard/admin-dashboard';

import { SuperAdminDashboardComponent }
from './dashboard/super-admin-dashboard/super-admin-dashboard';

import { authGuard } from './core/guards/auth.guard';
import { adminGuard } from './core/guards/admin.guard';
import { userGuard } from './core/guards/user.guard';
import { superAdminGuard } from './core/guards/super-admin.guard';
import { MyBorrowsComponent } from './borrow/my-borrows/my-borrows';
import { BookListComponent } from './books/book-list/book-list';
import { MyFinesComponent } from './fines/my-fines/my-fines';
import { AddBookComponent } from './books/add-book/add-book';
import { RegisterComponent } from './auth/register/register';

export const routes: Routes = [

  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },

  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  },

  {
    path: 'user-dashboard',
    component: UserDashboardComponent,
    canActivate: [authGuard, userGuard]
  },

  {
    path: 'admin-dashboard',
    component: AdminDashboardComponent,
    canActivate: [authGuard, adminGuard]
  },

  {
    path: 'super-admin-dashboard',
    component: SuperAdminDashboardComponent,
    canActivate: [authGuard, superAdminGuard]
  },

  {
  path: 'books',
  component: BookListComponent,
  canActivate: [authGuard]
},

{
  path: 'my-borrows',
  component: MyBorrowsComponent,
  canActivate: [authGuard]
},

{
  path: 'my-fines',
  component: MyFinesComponent,
  canActivate: [authGuard]
},
{
  path: 'add-book',
  component: AddBookComponent,
  canActivate: [authGuard]
}
];
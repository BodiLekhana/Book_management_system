import { Component, OnInit } from '@angular/core';
import { FineService } from '../../core/services/fine.service';
import { Fine } from '../../core/models/fine.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-my-fines',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-fines.html',
  styleUrls: ['./my-fines.css']
})
export class MyFinesComponent implements OnInit {

  fines: Fine[] = [];

  constructor(private service: FineService) {}

  ngOnInit(): void {
    this.loadFines();
  }

  loadFines() {
    this.service.getMyFines()
      .subscribe(data => this.fines = data);
  }

  payFine(id: number) {

    this.service.payFine(id)
      .subscribe(blob => {

        const url = window.URL.createObjectURL(blob);

        const a = document.createElement('a');

        a.href = url;
        a.download = 'receipt.pdf';
        a.click();

      });
  }
}
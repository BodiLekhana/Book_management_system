import { Component, OnInit } from '@angular/core';
import { FineService } from '../../core/services/fine.service';
import { Fine } from '../../core/models/fine.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-all-fines',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './all-fines.html',
  styleUrls: ['./all-fines.css']
})
export class AllFinesComponent implements OnInit {

  fines: Fine[] = [];

  constructor(private service: FineService) {}

  ngOnInit(): void {
    this.service.getAllFines()
      .subscribe(data => this.fines = data);
  }
}
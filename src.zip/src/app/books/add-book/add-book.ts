import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BookService } from '../../core/services/book.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-book',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './add-book.html',
  styleUrls: ['./add-book.css']
})
export class AddBookComponent {

  book = {
    title: '',
    author: '',
    category: '',
    price: 0,
    quantity: 1
  };

  constructor(
    private service: BookService,
    private router: Router
  ) {}

  saveBook() {
    this.service.addBook(this.book)
      .subscribe(() => {
        alert('Book Added');
        this.router.navigate(['/books']);
      });
  }
}
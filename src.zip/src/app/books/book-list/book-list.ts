import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookService } from '../../core/services/book.service';
import { BorrowService } from '../../core/services/borrow.service';
import { Book } from '../../core/models/book.model';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-book-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './book-list.html',
  styleUrls: ['./book-list.css']
})
export class BookListComponent implements OnInit {

  books: Book[] = [];
  //role = '';

  constructor(
    private bookService: BookService,
    private borrowService: BorrowService,
    public authService: AuthService
  ) {
    console.log('BOOK COMPONENT CREATED');
  }

  ngOnInit(): void {
    //this.role = localStorage.getItem('role') || '';
    this.loadBooks();
  }

  loadBooks() {
  this.bookService.getAllBooks()
    .subscribe(data => {
      console.log('BOOKS RECEIVED', data);
      this.books = [...data];
      // console.log('BOOKS ARRAY AFTER ASSIGN', this.books);
      console.log('BOOK COUNT', this.books.length);
    });
  }

  borrowBook(bookId: number) {
    this.borrowService.borrowBook(bookId)
      .subscribe(() => {
        alert('Book Borrowed');
        this.loadBooks();
      });
  }
//   isBorrowed(bookId: number): boolean {
//     return this.borrowBook.includes(bookId);
// }

  deleteBook(id: number) {
    if(confirm('Delete Book?')) {
      this.bookService.deleteBook(id)
        .subscribe(() => this.loadBooks());
    }
  }
}
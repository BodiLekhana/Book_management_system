import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { BookService } from '../../core/services/book.service';
import { Book } from '../../core/models/book.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-edit-book',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './edit-book.html',
  styleUrls: ['./edit-book.css']
})
export class EditBookComponent implements OnInit {

  book!: Book;

  constructor(
    private route: ActivatedRoute,
    private service: BookService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id =
      Number(this.route.snapshot.paramMap.get('id'));
    this.service.getBookById(id)
      .subscribe(data => {
        this.book = data;
      });
  }

  updateBook() {
    this.service.updateBook(this.book)
      .subscribe(() => {
        alert('Book Updated');
        this.router.navigate(['/books']);
      });
  }
}
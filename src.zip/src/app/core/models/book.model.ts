export interface Book {

  id?: number;

  title: string;

  category: string;

  author: string;

  price: number;
  
  quantity: number;
}
export interface Borrow {

  id?: number;

  bookId: number;

  userEmail: string;

  borrowDate: string;

  dueDate: string;

  returnDate?: string;

  returned: boolean;
}
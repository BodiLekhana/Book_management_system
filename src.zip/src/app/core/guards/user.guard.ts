import { CanActivateFn } from '@angular/router';

import { JwtUtil } from '../../utility/jwt.util';

export const userGuard: CanActivateFn =
(route, state) => {

  return JwtUtil.getRole() === 'USER';
};
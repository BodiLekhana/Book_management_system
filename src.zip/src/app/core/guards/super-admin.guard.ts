import { CanActivateFn } from '@angular/router';

import { JwtUtil } from '../../utility/jwt.util';

export const superAdminGuard: CanActivateFn =
(route, state) => {

  return JwtUtil.getRole() === 'SUPER_ADMIN';
};
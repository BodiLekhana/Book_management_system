import { CanActivateFn } from '@angular/router';

import { JwtUtil } from '../../utility/jwt.util';

export const adminGuard: CanActivateFn =
(route, state) => {

    const role = JwtUtil.getRole();

  return role === 'ADMIN'
      || role === 'SUPER_ADMIN';
};
import {
  HttpInterceptorFn,
  HttpErrorResponse
} from '@angular/common/http';

import { catchError, throwError } from 'rxjs';

export const errorInterceptor: HttpInterceptorFn =
(req, next) => {

  return next(req).pipe(

    catchError((error: HttpErrorResponse) => {

      if (error.status === 401) {

        alert('Session Expired. Please Login Again.');

        localStorage.clear();

        window.location.href = '/login';
      }

      if (error.status === 403) {

        alert('Access Denied');
      }

      if (error.status === 500) {

        alert('Server Error');
      }

      return throwError(() => error);
    })
  );
};
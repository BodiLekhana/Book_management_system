import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  private TOKEN_KEY = 'token';

  saveToken(token: string): void {

    localStorage.setItem(
      this.TOKEN_KEY,
      token
    );
  }

  getToken(): string | null {

    return localStorage.getItem(
      this.TOKEN_KEY
    );
  }

  clear(): void {

    localStorage.clear();
  }

  isLoggedIn(): boolean {

    return this.getToken() !== null;
  }

  getRole(): string {

  const token = this.getToken();

  if (!token) return '';

  const payload = JSON.parse(
    atob(token.split('.')[1])
  );

  return payload.role;
}
}
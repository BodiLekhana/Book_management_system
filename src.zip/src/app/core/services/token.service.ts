import { Injectable } from '@angular/core';
import { jwtDecode } from 'jwt-decode';
import { DecodedToken } from '../models/auth.model';

@Injectable({
  providedIn: 'root'
})
export class TokenService {
  private readonly TOKEN_KEY = 'auth_token';

  saveToken(token: string): void {
    localStorage.setItem(this.TOKEN_KEY, token);
  }

  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  removeToken(): void {
    localStorage.removeItem(this.TOKEN_KEY);
  }

  getDecodedToken(): DecodedToken | null {
    const token = this.getToken();
    if (!token) {
      return null;
    }
    try {
      return jwtDecode<DecodedToken>(token);
    } catch (e) {
      console.error('Failed to decode token:', e);
      return null;
    }
  }

  getUserEmail(): string | null {
    const decoded = this.getDecodedToken();
    if (!decoded) return null;
    return decoded.email || decoded.sub || null;
  }

  getUserRole(): string | null {
    const decoded = this.getDecodedToken();
    if (!decoded) return null;

    let rawRole: string | undefined;

    if (decoded.role && typeof decoded.role === 'string') {
      rawRole = decoded.role;
    } else if (Array.isArray(decoded.roles) && decoded.roles.length > 0) {
      rawRole = decoded.roles[0];
    } else if (typeof decoded.roles === 'string') {
      rawRole = decoded.roles;
    } else if (Array.isArray(decoded.authorities) && decoded.authorities.length > 0) {
      rawRole = decoded.authorities[0];
    } else if (typeof decoded.authorities === 'string') {
      rawRole = decoded.authorities;
    }

    if (!rawRole) return null;

    // Clean prefix like 'ROLE_' if present
    const cleanRole = rawRole.toUpperCase().replace(/^ROLE_/, '');

    if (['SUPER_ADMIN', 'ADMIN', 'USER'].includes(cleanRole)) {
      return cleanRole;
    }

    return cleanRole;
  }

  isTokenExpired(): boolean {
    const decoded = this.getDecodedToken();
    if (!decoded || !decoded.exp) {
      return false; // If exp not present, assume active if token exists
    }
    const currentTime = Math.floor(Date.now() / 1000);
    return decoded.exp < currentTime;
  }
}

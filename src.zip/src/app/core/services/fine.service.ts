import { Injectable } from '@angular/core';

import {
  HttpClient
} from '@angular/common/http';

import {
  Observable
} from 'rxjs';

import { API } from '../api.constants';

import {
  Fine
} from '../models/fine.model';

@Injectable({
  providedIn: 'root'
})
export class FineService {

  constructor(
    private http: HttpClient
  ) {}

  getMyFines(): Observable<Fine[]> {

    return this.http.get<Fine[]>(
      `${API.FINES}/my`
    );
  }

  getAllFines(): Observable<Fine[]> {

    return this.http.get<Fine[]>(
      `${API.FINES}/all`
    );
  }

  payFine(
    fineId: number
  ): Observable<Blob> {

    return this.http.get(
      `${API.FINES}/pay/${fineId}`,
      {
        responseType: 'blob'
      }
    );
  }
}
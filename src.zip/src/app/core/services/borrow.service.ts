import { Injectable } from '@angular/core';

import {
  HttpClient
} from '@angular/common/http';

import {
  Observable
} from 'rxjs';

import { API } from '../api.constants';

import {
  Borrow
} from '../models/borrow.model';

@Injectable({
  providedIn: 'root'
})
export class BorrowService {

  constructor(
    private http: HttpClient
  ) {}

  borrowBook(
    bookId: number
  ): Observable<Borrow> {

    return this.http.post<Borrow>(
      `${API.BORROW}/${bookId}`,
      {}
    );
  }

  returnBook(
    borrowId: number
  ): Observable<any> {

    return this.http.put(
      `${API.BORROW}/return/${borrowId}`,
      {},
    {
      responseType: 'text'
    }
    );
  }

  getMyBorrows(): Observable<Borrow[]> {

    return this.http.get<Borrow[]>(
      `${API.BORROW}/my-books`
    );
  }

  getAllBorrows(): Observable<Borrow[]> {

    return this.http.get<Borrow[]>(
      `${API.BORROW}/all`
    );
  }
}
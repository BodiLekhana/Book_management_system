import { Injectable } from '@angular/core';

import {
  HttpClient
} from '@angular/common/http';

import {
  Observable
} from 'rxjs';

import {
  LoginRequest
} from '../models/login-request.model';

import {
  RegisterRequest
} from '../models/register-request.model';

import {
  AuthResponse
} from '../models/auth-response.model';

import { API } from '../api.constants';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(
    private http: HttpClient
  ) {}

  register(data: any) {
    return this.http.post(
      `${API.AUTH}/register`,
      data,
    {
      responseType: 'text'
    }
    );
  }

  login(
    request: LoginRequest
  ): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(
      `${API.AUTH}/login`,
      request
    );
  }
  isAdmin(): boolean {
  const role = localStorage.getItem('role');
  return role === 'ADMIN' || role === 'SUPER_ADMIN';
}

isUser(): boolean {
  return localStorage.getItem('role') === 'USER';
}
}
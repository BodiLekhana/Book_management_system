import { Injectable } from '@angular/core';

import {
  HttpClient
} from '@angular/common/http';

import {
  Observable
} from 'rxjs';

import { API } from '../api.constants';

import {
  User
} from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(
    private http: HttpClient
  ) {}

  getAllUsers(): Observable<User[]> {

    return this.http.get<User[]>(
      `${API.USERS}/users`
    );
  }

  addAdmin(admin: any): Observable<any> {

    return this.http.post(
      `${API.USERS}/create-admin`,
      admin
    );
  }

  addSuperAdmin(admin: any): Observable<any> {

    return this.http.post(
      `${API.USERS}/create-super-admin`,
      admin
    );
  }

  getTotalUsers(): Observable<number> {

    return this.http.get<number>(
      `${API.USERS}/total-users`
    );
  }
}
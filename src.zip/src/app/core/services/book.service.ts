import { Injectable } from '@angular/core';

import {
  HttpClient
} from '@angular/common/http';

import {
  Observable
} from 'rxjs';

import { API } from '../api.constants';

import {
  Book
} from '../models/book.model';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(
    private http: HttpClient
  ) {}

  getAllBooks(): Observable<Book[]> {

    return this.http.get<Book[]>(
      API.BOOKS
    );
  }

  addBook(
    book: Book
  ): Observable<Book> {

    return this.http.post<Book>(
      `${API.BOOKS}/add`,
      book
    );
  }

  deleteBook(
    id: number
  ): Observable<any> {

    return this.http.delete(
      `${API.BOOKS}/${id}`
    );
  }

  getBookById(id: number): Observable<Book> {

  return this.http.get<Book>(
    `${API.BOOKS}/${id}`
  );
}

updateBook(book: Book): Observable<Book> {

  return this.http.put<Book>(
    `${API.BOOKS}/${book.id}`,
    book
  );
}
}
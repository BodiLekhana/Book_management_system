import { environment } from '../../environments/environment';

export const API = {

  GATEWAY: 'http://localhost:8085',

  AUTH: `${environment.apiUrl}/auth`,

  USERS: `${environment.apiUrl}/admin`,

  BOOKS: `${environment.apiUrl}/books`,

  BORROW: `${environment.apiUrl}/borrow`,

  FINES: `${environment.apiUrl}/fines`
};
import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { finalize } from 'rxjs';
import { FineService } from '../../../core/services/fine.service';
import { NotificationService } from '../../../core/services/notification.service';
import { Fine } from '../../../core/models/fine.model';
import { LoadingComponent } from '../../../shared/loading/loading';

@Component({
  selector: 'app-my-fines',
  standalone: true,
  imports: [CommonModule, LoadingComponent],
  template: `
    <div class="container-fluid p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 class="fw-bold mb-1">My Fines</h2>
          <p class="text-secondary small mb-0">Manage and pay your overdue fines</p>
        </div>
      </div>

      <app-loading *ngIf="isLoading" message="Fetching fine records..."></app-loading>

      <div *ngIf="!isLoading">
        <div *ngIf="fines.length === 0" class="text-center py-5 bg-white rounded-4 border">
          <i class="bi bi-shield-check fs-1 text-success"></i>
          <h5 class="fw-bold mt-2">No Outstanding Fines</h5>
          <p class="text-secondary">You do not have any fine records on file.</p>
        </div>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden" *ngIf="fines.length > 0">
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th class="py-3 px-4">Fine ID</th>
                  <th class="py-3">Borrow ID</th>
                  <th class="py-3">Amount</th>
                  <th class="py-3">Status</th>
                  <th class="py-3 text-end px-4">Action</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let fine of fines">
                  <td class="px-4 fw-bold text-secondary">#{{ fine.id }}</td>
                  <td class="fw-semibold">Borrow Record #{{ fine.borrowId }}</td>
                  <td><span class="fw-bold text-danger">₹{{ fine.amount }}</span></td>
                  <td>
                    <span class="badge" [ngClass]="fine.paid ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'">
                      {{ fine.paid ? 'Paid' : 'Unpaid' }}
                    </span>
                  </td>
                  <td class="text-end px-4">
                    <button
                      class="btn btn-sm btn-success rounded-3 px-3"
                      [disabled]="payingId === fine.id"
                      (click)="payFine(fine)">
                      <span *ngIf="payingId !== fine.id"><i class="bi bi-file-earmark-pdf me-1"></i> Pay / Download Receipt</span>
                      <span *ngIf="payingId === fine.id" class="spinner-border spinner-border-sm"></span>
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `
})
export class MyFinesComponent implements OnInit {
  private fineService = inject(FineService);
  private notificationService = inject(NotificationService);

  fines: Fine[] = [];
  isLoading = true;
  payingId: number | null = null;

  ngOnInit(): void {
    this.loadFines();
  }

  loadFines(): void {
    this.isLoading = true;
    this.fineService.getMyFines().pipe(
      finalize(() => this.isLoading = false)
    ).subscribe({
      next: (data) => {
        this.fines = data || [];
      }
    });
  }

  payFine(fine: Fine): void {
    if (!fine.id) return;
    this.payingId = fine.id;

    this.fineService.payFine(fine.id).pipe(
      finalize(() => {
        this.payingId = null;
      })
    ).subscribe({
      next: (blob: Blob) => {
        this.notificationService.showSuccess('Payment processed & PDF receipt generated!');

        // Trigger file download / open in browser
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `receipt_fine_${fine.id}.pdf`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);

        this.loadFines();
      },
      error: () => {}
    });
  }
}

import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BorrowService } from '../../../core/services/borrow.service';
import { NotificationService } from '../../../core/services/notification.service';
import { BorrowRecord } from '../../../core/models/borrow-record.model';
import { LoadingComponent } from '../../../shared/loading/loading';

@Component({
  selector: 'app-pending-borrows',
  standalone: true,
  imports: [CommonModule, LoadingComponent],
  template: `
    <div class="container-fluid p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 class="fw-bold mb-1">Pending Unreturned Books</h2>
          <p class="text-secondary small mb-0">Currently active borrowings that require return</p>
        </div>
      </div>

      <app-loading *ngIf="isLoading" message="Loading pending borrowings..."></app-loading>

      <div *ngIf="!isLoading">
        <div *ngIf="pendingRecords.length === 0" class="text-center py-5 bg-white rounded-4 border">
          <i class="bi bi-check-circle fs-1 text-success"></i>
          <h5 class="fw-bold mt-2">All Clear!</h5>
          <p class="text-secondary">You currently have no pending unreturned books.</p>
        </div>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden" *ngIf="pendingRecords.length > 0">
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th class="py-3 px-4">Borrow ID</th>
                  <th class="py-3">Book ID</th>
                  <th class="py-3">Borrow Date</th>
                  <th class="py-3">Due Date</th>
                  <th class="py-3">Status</th>
                  <th class="py-3 text-end px-4">Action</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let record of pendingRecords">
                  <td class="px-4 fw-bold text-secondary">#{{ record.id }}</td>
                  <td class="fw-semibold">Book #{{ record.bookId }}</td>
                  <td>{{ record.borrowDate | date:'mediumDate' }}</td>
                  <td><span class="text-danger fw-bold">{{ record.dueDate | date:'mediumDate' }}</span></td>
                  <td><span class="badge bg-warning-subtle text-warning">Pending Return</span></td>
                  <td class="text-end px-4">
                    <button
                      class="btn btn-sm btn-primary rounded-3 px-3"
                      [disabled]="returningId === record.id"
                      (click)="returnBook(record)">
                      <span *ngIf="returningId !== record.id"><i class="bi bi-arrow-return-left me-1"></i> Return Book</span>
                      <span *ngIf="returningId === record.id" class="spinner-border spinner-border-sm"></span>
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `
})
export class PendingBorrowsComponent implements OnInit {
  private borrowService = inject(BorrowService);
  private notificationService = inject(NotificationService);

  pendingRecords: BorrowRecord[] = [];
  isLoading = true;
  returningId: number | null = null;

  ngOnInit(): void {
    this.loadPending();
  }

  loadPending(): void {
    this.isLoading = true;
    this.borrowService.getPendingBorrows().subscribe({
      next: (data) => {
        this.pendingRecords = data || [];
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }

  returnBook(record: BorrowRecord): void {
    if (!record.id) return;
    this.returningId = record.id;

    this.borrowService.returnBook(record.id).subscribe({
      next: (res) => {
        this.returningId = null;
        this.notificationService.showSuccess(res || 'Book returned successfully!');
        this.loadPending();
      },
      error: () => {
        this.returningId = null;
      }
    });
  }
}

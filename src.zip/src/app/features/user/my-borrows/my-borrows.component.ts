import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BorrowService } from '../../../core/services/borrow.service';
import { NotificationService } from '../../../core/services/notification.service';
import { BorrowRecord } from '../../../core/models/borrow-record.model';
import { LoadingComponent } from '../../../shared/loading/loading';

@Component({
  selector: 'app-my-borrows',
  standalone: true,
  imports: [CommonModule, LoadingComponent],
  template: `
    <div class="container-fluid p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 class="fw-bold mb-1">My Borrow History</h2>
          <p class="text-secondary small mb-0">View all your active and past book borrowings</p>
        </div>
      </div>

      <app-loading *ngIf="isLoading" message="Fetching your borrow history..."></app-loading>

      <div *ngIf="!isLoading">
        <div *ngIf="borrowRecords.length === 0" class="text-center py-5 bg-white rounded-4 border">
          <i class="bi bi-journal-x fs-1 text-secondary"></i>
          <p class="text-secondary mt-2">You have not borrowed any books yet.</p>
        </div>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden" *ngIf="borrowRecords.length > 0">
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th class="py-3 px-4">Record ID</th>
                  <th class="py-3">Book ID</th>
                  <th class="py-3">Borrow Date</th>
                  <th class="py-3">Due Date</th>
                  <th class="py-3">Return Date</th>
                  <th class="py-3">Status</th>
                  <th class="py-3 text-end px-4">Action</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let record of borrowRecords">
                  <td class="px-4 fw-bold text-secondary">#{{ record.id }}</td>
                  <td class="fw-semibold">Book #{{ record.bookId }}</td>
                  <td>{{ record.borrowDate | date:'mediumDate' }}</td>
                  <td><span class="text-danger fw-medium">{{ record.dueDate | date:'mediumDate' }}</span></td>
                  <td>
                    <span *ngIf="record.returnDate">{{ record.returnDate | date:'mediumDate' }}</span>
                    <span *ngIf="!record.returnDate" class="text-muted">—</span>
                  </td>
                  <td>
                    <span class="badge" [ngClass]="record.returned ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning'">
                      {{ record.returned ? 'Returned' : 'Active Borrow' }}
                    </span>
                  </td>
                  <td class="text-end px-4">
                    <button
                      *ngIf="!record.returned"
                      class="btn btn-sm btn-outline-primary rounded-3 px-3"
                      [disabled]="returningId === record.id"
                      (click)="returnBook(record)">
                      <span *ngIf="returningId !== record.id"><i class="bi bi-arrow-return-left me-1"></i> Return Book</span>
                      <span *ngIf="returningId === record.id" class="spinner-border spinner-border-sm"></span>
                    </button>
                    <span *ngIf="record.returned" class="text-muted small">Completed</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `
})
export class MyBorrowsComponent implements OnInit {
  private borrowService = inject(BorrowService);
  private notificationService = inject(NotificationService);

  borrowRecords: BorrowRecord[] = [];
  isLoading = true;
  returningId: number | null = null;

  ngOnInit(): void {
    this.loadBorrows();
  }

  loadBorrows(): void {
    this.isLoading = true;
    this.borrowService.getMyBooks().subscribe({
      next: (data) => {
        this.borrowRecords = data || [];
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }

  returnBook(record: BorrowRecord): void {
    if (!record.id) return;
    this.returningId = record.id;

    this.borrowService.returnBook(record.id).subscribe({
      next: (res) => {
        this.returningId = null;
        this.notificationService.showSuccess(res || 'Book returned successfully!');
        this.loadBorrows();
      },
      error: () => {
        this.returningId = null;
      }
    });
  }
}

import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BorrowService } from '../../../core/services/borrow.service';
import { BorrowRecord } from '../../../core/models/borrow-record.model';
import { LoadingComponent } from '../../../shared/loading/loading';

@Component({
  selector: 'app-admin-borrows',
  standalone: true,
  imports: [CommonModule, LoadingComponent],
  template: `
    <div class="container-fluid p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 class="fw-bold mb-1">System Borrow Records</h2>
          <p class="text-secondary small mb-0">Overview of all borrowing transactions across the system</p>
        </div>
      </div>

      <app-loading *ngIf="isLoading" message="Fetching system borrow records..."></app-loading>

      <div *ngIf="!isLoading">
        <div *ngIf="borrowRecords.length === 0" class="text-center py-5 bg-white rounded-4 border">
          <i class="bi bi-journal-album fs-1 text-secondary"></i>
          <p class="text-secondary mt-2">No borrow records found.</p>
        </div>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden" *ngIf="borrowRecords.length > 0">
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th class="py-3 px-4">Borrow ID</th>
                  <th class="py-3">Book ID</th>
                  <th class="py-3">User Email</th>
                  <th class="py-3">Borrow Date</th>
                  <th class="py-3">Due Date</th>
                  <th class="py-3">Return Date</th>
                  <th class="py-3 px-4 text-end">Status</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let rec of borrowRecords">
                  <td class="px-4 fw-bold text-secondary">#{{ rec.id }}</td>
                  <td class="fw-semibold">Book #{{ rec.bookId }}</td>
                  <td class="text-dark fw-medium">{{ rec.userEmail }}</td>
                  <td>{{ rec.borrowDate | date:'mediumDate' }}</td>
                  <td><span class="text-danger font-weight-bold">{{ rec.dueDate | date:'mediumDate' }}</span></td>
                  <td>
                    <span *ngIf="rec.returnDate">{{ rec.returnDate | date:'mediumDate' }}</span>
                    <span *ngIf="!rec.returnDate" class="text-muted">—</span>
                  </td>
                  <td class="px-4 text-end">
                    <span class="badge" [ngClass]="rec.returned ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning'">
                      {{ rec.returned ? 'Returned' : 'Active / Pending' }}
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AdminBorrowsComponent implements OnInit {
  private borrowService = inject(BorrowService);

  borrowRecords: BorrowRecord[] = [];
  isLoading = true;

  ngOnInit(): void {
    this.borrowService.getAllRecords().subscribe({
      next: (data) => {
        this.borrowRecords = data || [];
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }
}

import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { finalize } from 'rxjs';
import { FineService } from '../../../core/services/fine.service';
import { NotificationService } from '../../../core/services/notification.service';
import { Fine } from '../../../core/models/fine.model';
import { LoadingComponent } from '../../../shared/loading/loading';

@Component({
  selector: 'app-admin-fines',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, LoadingComponent],
  template: `
    <div class="container-fluid p-4">
      <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
          <h2 class="fw-bold mb-1">Fine Management</h2>
          <p class="text-secondary small mb-0">View all system fines and issue new overdue fines</p>
        </div>

        <button class="btn btn-danger rounded-3 text-nowrap" (click)="openCreateModal()">
          <i class="bi bi-plus-circle me-1"></i> Issue New Fine
        </button>
      </div>

      <app-loading *ngIf="isLoading" message="Fetching fine records..."></app-loading>

      <div *ngIf="!isLoading">
        <div *ngIf="fines.length === 0" class="text-center py-5 bg-white rounded-4 border">
          <i class="bi bi-receipt fs-1 text-secondary"></i>
          <p class="text-secondary mt-2">No fine records found in the system.</p>
        </div>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden" *ngIf="fines.length > 0">
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th class="py-3 px-4">Fine ID</th>
                  <th class="py-3">User Email</th>
                  <th class="py-3">Borrow ID</th>
                  <th class="py-3">Amount</th>
                  <th class="py-3 px-4 text-end">Status</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let fine of fines">
                  <td class="px-4 fw-bold text-secondary">#{{ fine.id }}</td>
                  <td class="fw-semibold text-dark">{{ fine.userEmail }}</td>
                  <td>Borrow Record #{{ fine.borrowId }}</td>
                  <td><span class="fw-bold text-danger">₹{{ fine.amount }}</span></td>
                  <td class="px-4 text-end">
                    <span class="badge" [ngClass]="fine.paid ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'">
                      {{ fine.paid ? 'Paid' : 'Unpaid' }}
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Create Fine Modal -->
      <div class="modal fade show d-block" tabindex="-1" *ngIf="showModal" style="background: rgba(0,0,0,0.5);">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 pb-0">
              <h5 class="modal-title fw-bold text-dark">Issue Fine</h5>
              <button type="button" class="btn-close" (click)="closeModal()"></button>
            </div>
            <div class="modal-body p-4">
              <form [formGroup]="fineForm" (ngSubmit)="saveFine()">
                <div class="mb-3">
                  <label class="form-label small fw-semibold text-secondary">User Email</label>
                  <input type="email" class="form-control" formControlName="email" placeholder="user@gmail.com" />
                  <div class="text-danger small mt-1" *ngIf="fineForm.get('email')?.touched && fineForm.get('email')?.hasError('required')">Email is required</div>
                  <div class="text-danger small mt-1" *ngIf="fineForm.get('email')?.touched && fineForm.get('email')?.hasError('email')">Invalid email address</div>
                </div>

                <div class="mb-3">
                  <label class="form-label small fw-semibold text-secondary">Borrow Record ID</label>
                  <input type="number" class="form-control" formControlName="borrowId" placeholder="e.g. 5" />
                  <div class="text-danger small mt-1" *ngIf="fineForm.get('borrowId')?.touched && fineForm.get('borrowId')?.hasError('required')">Borrow ID is required</div>
                </div>

                <div class="mb-4">
                  <label class="form-label small fw-semibold text-secondary">Fine Amount (₹)</label>
                  <input type="number" class="form-control" formControlName="amount" placeholder="e.g. 100" />
                  <div class="text-danger small mt-1" *ngIf="fineForm.get('amount')?.touched && fineForm.get('amount')?.hasError('required')">Amount is required</div>
                </div>

                <div class="d-flex justify-content-end gap-2 pt-3 border-top">
                  <button type="button" class="btn btn-light rounded-3" (click)="closeModal()">Cancel</button>
                  <button type="submit" class="btn btn-danger rounded-3 px-4" [disabled]="fineForm.invalid || isSaving">
                    <span *ngIf="!isSaving">Issue Fine</span>
                    <span *ngIf="isSaving" class="spinner-border spinner-border-sm"></span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AdminFinesComponent implements OnInit {
  private fineService = inject(FineService);
  private notificationService = inject(NotificationService);
  private fb = inject(FormBuilder);

  fines: Fine[] = [];
  isLoading = true;

  showModal = false;
  isSaving = false;

  fineForm: FormGroup = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    borrowId: [null, [Validators.required, Validators.min(1)]],
    amount: [100, [Validators.required, Validators.min(1)]]
  });

  ngOnInit(): void {
    this.loadFines();
  }

  loadFines(): void {
    this.isLoading = true;
    this.fineService.getAllFines().pipe(
      finalize(() => this.isLoading = false)
    ).subscribe({
      next: (data) => {
        this.fines = data || [];
      }
    });
  }

  openCreateModal(): void {
    this.fineForm.reset({ email: '', borrowId: null, amount: 100 });
    this.showModal = true;
  }

  closeModal(): void {
    this.showModal = false;
  }

  saveFine(): void {
    if (this.fineForm.invalid) return;

    this.isSaving = true;
    const { email, borrowId, amount } = this.fineForm.value;

    this.fineService.createFine(email, borrowId, amount).subscribe({
      next: () => {
        this.isSaving = false;
        this.notificationService.showSuccess('Fine issued successfully!');
        this.closeModal();
        this.loadFines();
      },
      error: () => {
        this.isSaving = false;
      }
    });
  }
}

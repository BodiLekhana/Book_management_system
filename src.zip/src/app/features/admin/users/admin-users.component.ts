import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../core/services/admin.service';
import { User } from '../../../core/models/user.model';
import { LoadingComponent } from '../../../shared/loading/loading';

@Component({
  selector: 'app-admin-users',
  standalone: true,
  imports: [CommonModule, LoadingComponent],
  template: `
    <div class="container-fluid p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 class="fw-bold mb-1">User Directory</h2>
          <p class="text-secondary small mb-0">List of all registered system users and their roles</p>
        </div>
      </div>

      <app-loading *ngIf="isLoading" message="Fetching registered users..."></app-loading>

      <div *ngIf="!isLoading">
        <div *ngIf="users.length === 0" class="text-center py-5 bg-white rounded-4 border">
          <i class="bi bi-people fs-1 text-secondary"></i>
          <p class="text-secondary mt-2">No registered users found.</p>
        </div>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden" *ngIf="users.length > 0">
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th class="py-3 px-4">User ID</th>
                  <th class="py-3">Email Address</th>
                  <th class="py-3 px-4 text-end">Assigned Role</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let u of users">
                  <td class="px-4 fw-bold text-secondary">#{{ u.id }}</td>
                  <td class="fw-semibold text-dark">{{ u.email }}</td>
                  <td class="px-4 text-end">
                    <span class="badge" [ngClass]="{
                      'bg-primary-subtle text-primary': u.role === 'USER',
                      'bg-warning-subtle text-warning': u.role === 'ADMIN',
                      'bg-danger-subtle text-danger': u.role === 'SUPER_ADMIN'
                    }">{{ u.role }}</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AdminUsersComponent implements OnInit {
  private adminService = inject(AdminService);

  users: User[] = [];
  isLoading = true;

  ngOnInit(): void {
    this.adminService.getAllUsers().subscribe({
      next: (data) => {
        this.users = data || [];
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }
}

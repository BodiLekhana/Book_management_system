import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { AdminService } from '../../../core/services/admin.service';
import { BookService } from '../../../core/services/book.service';
import { BorrowService } from '../../../core/services/borrow.service';
import { FineService } from '../../../core/services/fine.service';
import { LoadingComponent } from '../../../shared/loading/loading';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, LoadingComponent],
  template: `
    <div class="container-fluid p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 class="fw-bold mb-1">Admin Dashboard</h2>
          <p class="text-secondary small mb-0">System Overview & Administrative Controls</p>
        </div>
      </div>

      <app-loading *ngIf="isLoading" message="Loading admin statistics..."></app-loading>

      <div *ngIf="!isLoading">
        <div class="row g-4 mb-5">
          <div class="col-12 col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
              <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-secondary small fw-semibold text-uppercase">Total Registered Users</div>
                  <div class="display-6 fw-bold text-primary mt-1">{{ totalUsers }}</div>
                </div>
                <div class="bg-primary-subtle text-primary p-3 rounded-circle fs-3">
                  <i class="bi bi-people"></i>
                </div>
              </div>
              <div class="card-footer bg-transparent border-0 px-4 pb-3">
                <a routerLink="/admin/users" class="text-primary small text-decoration-none fw-semibold">Manage Users <i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
              <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-secondary small fw-semibold text-uppercase">Total Catalog Books</div>
                  <div class="display-6 fw-bold text-success mt-1">{{ totalBooks }}</div>
                </div>
                <div class="bg-success-subtle text-success p-3 rounded-circle fs-3">
                  <i class="bi bi-book-half"></i>
                </div>
              </div>
              <div class="card-footer bg-transparent border-0 px-4 pb-3">
                <a routerLink="/admin/books" class="text-success small text-decoration-none fw-semibold">Manage Books <i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
              <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-secondary small fw-semibold text-uppercase">Total Borrow Records</div>
                  <div class="display-6 fw-bold text-warning mt-1">{{ totalBorrows }}</div>
                </div>
                <div class="bg-warning-subtle text-warning p-3 rounded-circle fs-3">
                  <i class="bi bi-arrow-left-right"></i>
                </div>
              </div>
              <div class="card-footer bg-transparent border-0 px-4 pb-3">
                <a routerLink="/admin/borrows" class="text-warning small text-decoration-none fw-semibold">View Borrows <i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
              <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-secondary small fw-semibold text-uppercase">Total Fine Records</div>
                  <div class="display-6 fw-bold text-danger mt-1">{{ totalFines }}</div>
                </div>
                <div class="bg-danger-subtle text-danger p-3 rounded-circle fs-3">
                  <i class="bi bi-receipt"></i>
                </div>
              </div>
              <div class="card-footer bg-transparent border-0 px-4 pb-3">
                <a routerLink="/admin/fines" class="text-danger small text-decoration-none fw-semibold">Manage Fines <i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>
        </div>

        <!-- Admin Quick Actions -->
        <div class="row g-4">
          <div class="col-12 col-md-6">
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
              <div class="d-flex align-items-center gap-3">
                <div class="bg-primary text-white p-3 rounded-3">
                  <i class="bi bi-plus-circle fs-3"></i>
                </div>
                <div>
                  <h5 class="fw-bold mb-1">Add New Book</h5>
                  <p class="text-secondary small mb-2">Create new book entry in the library catalog.</p>
                  <a routerLink="/admin/books" class="btn btn-outline-primary btn-sm rounded-3">Go to Book Management</a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-12 col-md-6">
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
              <div class="d-flex align-items-center gap-3">
                <div class="bg-danger text-white p-3 rounded-3">
                  <i class="bi bi-calculator fs-3"></i>
                </div>
                <div>
                  <h5 class="fw-bold mb-1">Impose Fine</h5>
                  <p class="text-secondary small mb-2">Issue fine record for overdue borrows.</p>
                  <a routerLink="/admin/fines" class="btn btn-outline-danger btn-sm rounded-3">Go to Fine Management</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AdminDashboardComponent implements OnInit {
  private adminService = inject(AdminService);
  private bookService = inject(BookService);
  private borrowService = inject(BorrowService);
  private fineService = inject(FineService);

  isLoading = true;
  totalUsers = 0;
  totalBooks = 0;
  totalBorrows = 0;
  totalFines = 0;

  // ngOnInit(): void {
  //   forkJoin({
  //     users: this.adminService.getAllUsers(),
  //     books: this.bookService.getAllBooks(),
  //     borrows: this.borrowService.getAllRecords(),
  //     fines: this.fineService.getAllFines()
  //   }).subscribe({
  //     next: (res) => {
  //       this.totalUsers = res.users.length;
  //       this.totalBooks = res.books.length;
  //       this.totalBorrows = res.borrows.length;
  //       this.totalFines = res.fines.length;
  //       this.isLoading = false;
  //     },
  //     error: () => {
  //       this.isLoading = false;
  //     }
  //   });
  // }
  ngOnInit(): void {
  console.log('ADMIN DASHBOARD: ngOnInit started');

  forkJoin({
    users: this.adminService.getAllUsers(),
    books: this.bookService.getAllBooks(),
    borrows: this.borrowService.getAllRecords(),
    fines: this.fineService.getAllFines()
  }).subscribe({
    next: (res) => {
      console.log('ADMIN DASHBOARD RESPONSE:', res);

      console.log('users:', res.users);
      console.log('books:', res.books);
      console.log('borrows:', res.borrows);
      console.log('fines:', res.fines);

      this.totalUsers = Array.isArray(res.users) ? res.users.length : 0;
      this.totalBooks = Array.isArray(res.books) ? res.books.length : 0;
      this.totalBorrows = Array.isArray(res.borrows) ? res.borrows.length : 0;
      this.totalFines = Array.isArray(res.fines) ? res.fines.length : 0;

      console.log('Setting isLoading = false');

      this.isLoading = false;
    },
    error: (error) => {
      console.error('ADMIN DASHBOARD ERROR:', error);

      this.isLoading = false;
    },
    complete: () => {
      console.log('ADMIN DASHBOARD forkJoin completed');
    }
  });
}
}

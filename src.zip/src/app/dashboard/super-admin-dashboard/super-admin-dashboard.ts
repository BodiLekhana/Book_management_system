import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { AddBookComponent }
from '../../books/add-book/add-book';
import { UserService } from '../../core/services/user.service';
import { BookService } from '../../core/services/book.service';
import { Book } from '../../core/models/book.model';
import { FormsModule } from '@angular/forms';
import { OnInit } from '@angular/core';
import { User } from '../../core/models/user.model';
@Component({
  selector: 'app-super-admin-dashboard',
  standalone: true,
  imports: [CommonModule,RouterModule,FormsModule],
  templateUrl: './super-admin-dashboard.html',
  styleUrls: ['./super-admin-dashboard.css']
})
export class SuperAdminDashboardComponent implements OnInit {
   books: Book[] = [];
  filteredBooks: Book[] = [];
  users: any[] = [];

  searchText = '';

  admin = {
    email: '',
    password: ''
  };

  constructor(
    private bookService: BookService,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.loadBooks();
    this.userService.getAllUsers().subscribe(data => {
  this.users = data;
});
  }

  loadBooks() {

    this.bookService.getAllBooks()
      .subscribe(data => {

        this.books = data;
        this.filteredBooks = data;

      });
  }

  searchBooks() {

    this.filteredBooks = this.books.filter(book =>

      book.title
        .toLowerCase()
        .includes(
          this.searchText.toLowerCase()
        )

    );
  }

  addAdmin() {

    this.userService.addAdmin(this.admin)
      .subscribe(() => {

        alert('Admin Added Successfully');

        this.admin = {
          email: '',
          password: ''
        };

      });
  }
}
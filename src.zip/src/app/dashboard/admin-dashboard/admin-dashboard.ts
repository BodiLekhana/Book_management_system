import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { BookService } from '../../core/services/book.service';
import { BorrowService } from '../../core/services/borrow.service';
import { FineService } from '../../core/services/fine.service';
import { UserService } from '../../core/services/user.service';

import { Book } from '../../core/models/book.model';
import { Borrow } from '../../core/models/borrow.model';
import { Fine } from '../../core/models/fine.model';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './admin-dashboard.html',
  styleUrls: ['./admin-dashboard.css']
})
export class AdminDashboardComponent {
   books: Book[] = [];
  borrows: Borrow[] = [];
  fines: Fine[] = [];
  users: any[] = [];

  searchText = '';
  filteredBooks: Book[] = [];

  constructor(
    private bookService: BookService,
    private borrowService: BorrowService,
    private fineService: FineService,
    private userService: UserService
  ) {}

  ngOnInit(): void {

    this.loadBooks();
    this.loadBorrows();
    this.loadFines();
    this.loadUsers();

  }

  loadBooks() {

    this.bookService.getAllBooks()
      .subscribe(data => {

        this.books = data;
        this.filteredBooks = data;

      });
  }

  loadBorrows() {

    this.borrowService.getAllBorrows()
      .subscribe(data => {

        this.borrows = data;

      });
  }

  loadFines() {

    this.fineService.getAllFines()
      .subscribe(data => {

        this.fines = data;

      });
  }

  loadUsers() {

    this.userService.getAllUsers()
      .subscribe(data => {

        this.users = data;

      });
  }

  searchBooks() {

    this.filteredBooks = this.books.filter(book =>

      book.title
        .toLowerCase()
        .includes(
          this.searchText.toLowerCase()
        )

    );
  }
}
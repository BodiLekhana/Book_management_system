import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';


@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class RegisterComponent {

  email = '';
  password = '';
  role = 'USER';
  // private router = inject(Router);

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  register() {
    const payload = {
      email: this.email,
      password: this.password,
      role: this.role
    };
    this.authService.register(payload)
      .subscribe({
        next: () => {
          alert('User Registered');
          
          this.email = '';
          this.password = '';
          this.router.navigate(['/login']);
        },
        error: console.error
      });
  }
}
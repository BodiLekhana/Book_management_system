import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { StorageService } from '../../core/services/storage.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule,RouterModule, FormsModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class LoginComponent {

  email = '';
  password = '';

  constructor(
    private authService: AuthService,
    private storageService: StorageService,
    private router: Router
  ) {}

  login() {
    const payload = {
      email: this.email,
      password: this.password
    };
    this.authService.login(payload)
      .subscribe({
        next: (response) => {
          this.storageService.saveToken(response.token);
          const role = this.storageService.getRole();
          if(role === 'SUPER_ADMIN') {
            this.router.navigate(['/super-admin-dashboard']);
          }
          else if(role === 'ADMIN') {
            this.router.navigate(['/admin-dashboard']);
          }
          else {
            this.router.navigate(['/user-dashboard']);
          }
        },
        error: () => {
          alert('Invalid Credentials');
        }
      });
  }
}
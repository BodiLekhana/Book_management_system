import { NgModule } from '@angular/core';

import { NavbarComponent }
from './navbar/navbar';

import { SidebarComponent }
from './sidebar/sidebar';

import { FooterComponent }
from './footer/footer';

@NgModule({

  imports: [
    NavbarComponent,
    SidebarComponent,
    FooterComponent
  ],

  exports: [
    NavbarComponent,
    SidebarComponent,
    FooterComponent
  ]
})
export class SharedModule {}
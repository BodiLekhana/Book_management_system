import {
 Component,
 Input,
 Output,
 EventEmitter
} from '@angular/core';

import { CommonModule } from '@angular/common';

@Component({
 selector: 'app-confirmation-dialog',
 standalone: true,
 imports: [CommonModule],
 templateUrl: './confirmation-dialog.html',
 styleUrls: ['./confirmation-dialog.css']
})
export class ConfirmationDialogComponent {

 @Input()
 message = '';

 @Output()
 confirm =
 new EventEmitter<void>();

 @Output()
 cancel =
 new EventEmitter<void>();

 onConfirm() {

   this.confirm.emit();
 }

 onCancel() {

   this.cancel.emit();
 }
}
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './navbar.html',
  styleUrls: ['./navbar.css']
})
export class NavbarComponent {

  constructor(public router: Router) {}

  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('token');
  }

  getRole(): string {
    const token = localStorage.getItem('token');

    if (!token) return '';

    const payload = JSON.parse(
      atob(token.split('.')[1])
    );

    return payload.role || '';
  }

  getEmail(): string {
    return '';
  }
}
export class JwtUtil {

  static getToken(): string | null {

    return localStorage.getItem('token');
  }

  static decodeToken(): any {

    const token = this.getToken();

    if (!token) return null;

    try {

      const payload = token.split('.')[1];

      return JSON.parse(atob(payload));

    } catch {

      return null;
    }
  }

  static getEmail(): string {

    const decoded = this.decodeToken();

    return decoded?.sub || '';
  }

  static getRole(): string {

    const decoded = this.decodeToken();

    return decoded?.role || '';
  }

  static isLoggedIn(): boolean {

    return !!this.getToken();
  }

  static logout(): void {

    localStorage.clear();
  }
}
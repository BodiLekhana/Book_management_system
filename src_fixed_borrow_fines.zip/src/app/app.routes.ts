import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

import { LoginComponent } from './features/auth/login/login.component';
import { RegisterComponent } from './features/auth/register/register.component';

import { UserDashboardComponent } from './features/user/dashboard/user-dashboard.component';
import { UserBooksComponent } from './features/user/books/user-books.component';
import { MyBorrowsComponent } from './features/user/my-borrows/my-borrows.component';
import { PendingBorrowsComponent } from './features/user/pending-borrows/pending-borrows.component';
import { MyFinesComponent } from './features/user/my-fines/my-fines.component';

import { AdminDashboardComponent } from './features/admin/dashboard/admin-dashboard.component';
import { AdminBooksComponent } from './features/admin/books/admin-books.component';
import { AdminUsersComponent } from './features/admin/users/admin-users.component';
import { AdminBorrowsComponent } from './features/admin/borrows/admin-borrows.component';
import { AdminFinesComponent } from './features/admin/fines/admin-fines.component';

import { SuperAdminDashboardComponent } from './features/super-admin/dashboard/super-admin-dashboard.component';
import { CreateAdminComponent } from './features/super-admin/create-admin/create-admin.component';

import { NotFoundComponent } from './shared/not-found/not-found';
import { UnauthorizedComponent } from './shared/unauthorized/unauthorized';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },

  // User Routes
  {
    path: 'user/dashboard',
    component: UserDashboardComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['USER'] }
  },
  {
    path: 'user/books',
    component: UserBooksComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['USER'] }
  },
  {
    path: 'user/borrows',
    component: MyBorrowsComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['USER'] }
  },
  {
    path: 'user/pending',
    component: PendingBorrowsComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['USER'] }
  },
  {
    path: 'user/fines',
    component: MyFinesComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['USER'] }
  },

  // Admin Routes
  {
    path: 'admin/dashboard',
    component: AdminDashboardComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['ADMIN'] }
  },
  {
    path: 'admin/books',
    component: AdminBooksComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['ADMIN'] }
  },
  {
    path: 'admin/users',
    component: AdminUsersComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['ADMIN'] }
  },
  {
    path: 'admin/borrows',
    component: AdminBorrowsComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['ADMIN'] }
  },
  {
    path: 'admin/fines',
    component: AdminFinesComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['ADMIN'] }
  },

  // Super Admin Routes
  {
    path: 'super-admin/dashboard',
    component: SuperAdminDashboardComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['SUPER_ADMIN'] }
  },
  {
    path: 'super-admin/create-admin',
    component: CreateAdminComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['SUPER_ADMIN'] }
  },
  {
    path: 'super-admin/create-super-admin',
    component: CreateAdminComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['SUPER_ADMIN'] }
  },
  {
    path: 'super-admin/users',
    component: AdminUsersComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['SUPER_ADMIN'] }
  },
  {
    path: 'super-admin/books',
    component: AdminBooksComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['SUPER_ADMIN'] }
  },
  {
    path: 'super-admin/borrows',
    component: AdminBorrowsComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['SUPER_ADMIN'] }
  },
  {
    path: 'super-admin/fines',
    component: AdminFinesComponent,
    canActivate: [authGuard, roleGuard],
    data: { roles: ['SUPER_ADMIN'] }
  },

  { path: 'unauthorized', component: UnauthorizedComponent },
  { path: '**', component: NotFoundComponent }
];

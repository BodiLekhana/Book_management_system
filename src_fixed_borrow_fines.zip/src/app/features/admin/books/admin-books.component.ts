import { Component, OnInit, ChangeDetectorRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { finalize, timeout, catchError, of } from 'rxjs';
import { BookService } from '../../../core/services/book.service';
import { NotificationService } from '../../../core/services/notification.service';
import { Book } from '../../../core/models/book.model';
import { LoadingComponent } from '../../../shared/loading/loading';
import { ConfirmationDialogComponent } from '../../../shared/confirmation-dialog/confirmation-dialog';

@Component({
  selector: 'app-admin-books',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, MatDialogModule, LoadingComponent],
  template: `
    <div class="container-fluid p-4">
      <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
          <h2 class="fw-bold mb-1">Book Management</h2>
          <p class="text-secondary small mb-0">View, add, update, and remove library books</p>
        </div>

        <div class="d-flex gap-2">
          <input type="text" class="form-control" placeholder="Search books..." [(ngModel)]="searchTerm" (ngModelChange)="applyFilter()">
          <button class="btn btn-primary rounded-3 text-nowrap" (click)="openAddModal()">
            <i class="bi bi-plus-lg me-1"></i> Add New Book
          </button>
        </div>
      </div>

      <app-loading *ngIf="isLoading" message="Fetching catalog books..."></app-loading>

      <div *ngIf="!isLoading">
        <div *ngIf="filteredBooks.length === 0" class="text-center py-5 bg-white rounded-4 border">
          <i class="bi bi-book fs-1 text-secondary"></i>
          <p class="text-secondary mt-2">No books found in the library.</p>
        </div>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden" *ngIf="filteredBooks.length > 0">
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th class="py-3 px-4">ID</th>
                  <th class="py-3">Title</th>
                  <th class="py-3">Author</th>
                  <th class="py-3">Category</th>
                  <th class="py-3">Price</th>
                  <th class="py-3">Quantity</th>
                  <th class="py-3 text-end px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let book of filteredBooks">
                  <td class="px-4 fw-bold text-secondary">#{{ book.id }}</td>
                  <td class="fw-semibold text-dark">{{ book.title }}</td>
                  <td class="text-secondary">{{ book.author }}</td>
                  <td><span class="badge bg-secondary-subtle text-secondary rounded-pill px-2.5 py-1">{{ book.category }}</span></td>
                  <td class="fw-bold text-dark">₹{{ book.price }}</td>
                  <td>
                    <span class="badge" [ngClass]="book.quantity > 0 ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'">
                      {{ book.quantity }} in stock
                    </span>
                  </td>
                  <td class="text-end px-4">
                    <button class="btn btn-sm btn-outline-secondary me-2 rounded-3" (click)="openEditModal(book)" title="Edit Book">
                      <i class="bi bi-pencil"></i> Edit
                    </button>
                    <button class="btn btn-sm btn-outline-danger rounded-3" (click)="confirmDelete(book)" title="Delete Book">
                      <i class="bi bi-trash"></i> Delete
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Add/Edit Book Form Modal -->
      <div class="modal fade show d-block" tabindex="-1" *ngIf="showModal" style="background: rgba(0,0,0,0.5);">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header border-0 pb-0">
              <h5 class="modal-title fw-bold text-dark">{{ isEditMode ? 'Edit Book' : 'Add New Book' }}</h5>
              <button type="button" class="btn-close" (click)="closeModal()"></button>
            </div>
            <div class="modal-body p-4">
              <form [formGroup]="bookForm" (ngSubmit)="saveBook()">
                <div class="mb-3">
                  <label class="form-label small fw-semibold text-secondary">Book Title</label>
                  <input type="text" class="form-control" formControlName="title" placeholder="e.g. Clean Code" />
                  <div class="text-danger small mt-1" *ngIf="bookForm.get('title')?.touched && bookForm.get('title')?.hasError('required')">Title is required</div>
                </div>

                <div class="mb-3">
                  <label class="form-label small fw-semibold text-secondary">Author</label>
                  <input type="text" class="form-control" formControlName="author" placeholder="e.g. Robert C. Martin" />
                  <div class="text-danger small mt-1" *ngIf="bookForm.get('author')?.touched && bookForm.get('author')?.hasError('required')">Author is required</div>
                </div>

                <div class="mb-3">
                  <label class="form-label small fw-semibold text-secondary">Category</label>
                  <input type="text" class="form-control" formControlName="category" placeholder="e.g. Programming" />
                  <div class="text-danger small mt-1" *ngIf="bookForm.get('category')?.touched && bookForm.get('category')?.hasError('required')">Category is required</div>
                </div>

                <div class="row g-3 mb-4">
                  <div class="col-6">
                    <label class="form-label small fw-semibold text-secondary">Price (₹)</label>
                    <input type="number" class="form-control" formControlName="price" placeholder="500" />
                    <div class="text-danger small mt-1" *ngIf="bookForm.get('price')?.touched && bookForm.get('price')?.hasError('required')">Price is required</div>
                  </div>
                  <div class="col-6">
                    <label class="form-label small fw-semibold text-secondary">Quantity</label>
                    <input type="number" class="form-control" formControlName="quantity" placeholder="10" />
                    <div class="text-danger small mt-1" *ngIf="bookForm.get('quantity')?.touched && bookForm.get('quantity')?.hasError('required')">Quantity is required</div>
                  </div>
                </div>

                <div class="d-flex justify-content-end gap-2 pt-3 border-top">
                  <button type="button" class="btn btn-light rounded-3" (click)="closeModal()">Cancel</button>
                  <button type="submit" class="btn btn-primary rounded-3 px-4" [disabled]="bookForm.invalid || isSaving">
                    <span *ngIf="!isSaving">{{ isEditMode ? 'Update Book' : 'Add Book' }}</span>
                    <span *ngIf="isSaving" class="spinner-border spinner-border-sm"></span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AdminBooksComponent implements OnInit {
  private bookService = inject(BookService);
  private notificationService = inject(NotificationService);
  private dialog = inject(MatDialog);
  private fb = inject(FormBuilder);
  private cdr = inject(ChangeDetectorRef);

  books: Book[] = [];
  filteredBooks: Book[] = [];
  isLoading = true;
  searchTerm = '';

  showModal = false;
  isEditMode = false;
  editingBookId: number | null = null;
  isSaving = false;

  bookForm: FormGroup = this.fb.group({
    title: ['', Validators.required],
    author: ['', Validators.required],
    category: ['', Validators.required],
    price: [0, [Validators.required, Validators.min(0)]],
    quantity: [1, [Validators.required, Validators.min(0)]]
  });

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks(): void {
    this.isLoading = true;
    this.bookService.getAllBooks().pipe(
      timeout(5000),
      catchError(() => of([])),
      finalize(() => {
        this.isLoading = false;
        this.cdr.markForCheck();
        this.cdr.detectChanges();
      })
    ).subscribe({
      next: (data) => {
        this.books = data || [];
        this.applyFilter();
        this.cdr.markForCheck();
        this.cdr.detectChanges();
      }
    });
  }

  applyFilter(): void {
    if (!this.searchTerm.trim()) {
      this.filteredBooks = [...this.books];
      return;
    }
    const term = this.searchTerm.toLowerCase();
    this.filteredBooks = this.books.filter(b =>
      b.title.toLowerCase().includes(term) ||
      b.author.toLowerCase().includes(term) ||
      b.category.toLowerCase().includes(term)
    );
  }

  openAddModal(): void {
    this.isEditMode = false;
    this.editingBookId = null;
    this.bookForm.reset({ title: '', author: '', category: '', price: 0, quantity: 1 });
    this.showModal = true;
  }

  openEditModal(book: Book): void {
    if (!book.id) return;
    this.isEditMode = true;
    this.editingBookId = book.id;
    this.bookForm.patchValue({
      title: book.title,
      author: book.author,
      category: book.category,
      price: book.price,
      quantity: book.quantity
    });
    this.showModal = true;
  }

  closeModal(): void {
    this.showModal = false;
    this.bookForm.reset();
  }

  saveBook(): void {
    if (this.bookForm.invalid) return;

    this.isSaving = true;
    const bookData: Book = this.bookForm.value;

    if (this.isEditMode && this.editingBookId) {
      this.bookService.updateBook(this.editingBookId, bookData).subscribe({
        next: () => {
          this.isSaving = false;
          this.notificationService.showSuccess('Book updated successfully!');
          this.closeModal();
          this.loadBooks();
        },
        error: () => {
          this.isSaving = false;
        }
      });
    } else {
      this.bookService.addBook(bookData).subscribe({
        next: () => {
          this.isSaving = false;
          this.notificationService.showSuccess('Book added successfully!');
          this.closeModal();
          this.loadBooks();
        },
        error: () => {
          this.isSaving = false;
        }
      });
    }
  }

  confirmDelete(book: Book): void {
    if (!book.id) return;

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '400px',
      data: {
        title: 'Delete Book',
        message: `Are you sure you want to delete "${book.title}"? This action cannot be undone.`,
        confirmText: 'Delete'
      }
    });

    dialogRef.afterClosed().subscribe(confirmed => {
      if (confirmed && book.id) {
        this.bookService.deleteBook(book.id).subscribe({
          next: (msg) => {
            this.notificationService.showSuccess(msg || 'Book deleted successfully!');
            this.loadBooks();
          }
        });
      }
    });
  }
}

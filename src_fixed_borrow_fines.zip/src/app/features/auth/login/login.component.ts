import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/notification.service';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatFormFieldModule,
    MatProgressSpinnerModule
  ],
  template: `
    <div class="d-flex align-items-center justify-content-center min-vh-100 bg-light py-5">
      <div class="card shadow-lg border-0 rounded-4 p-4" style="max-width: 420px; width: 100%;">
        <div class="text-center mb-4">
          <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-2" style="width: 56px; height: 56px;">
            <i class="bi bi-person-lock fs-2"></i>
          </div>
          <h3 class="fw-bold text-dark">Welcome Back</h3>
          <p class="text-secondary small">Login to access your Library Management System</p>
        </div>

        <form [formGroup]="loginForm" (ngSubmit)="onSubmit()">
          <div class="mb-3">
            <mat-form-field appearance="outline" class="w-100">
              <mat-label>Email Address</mat-label>
              <input matInput formControlName="email" type="email" placeholder="name@example.com" />
              <mat-error *ngIf="loginForm.get('email')?.hasError('required')">Email is required</mat-error>
              <mat-error *ngIf="loginForm.get('email')?.hasError('email')">Enter a valid email address</mat-error>
            </mat-form-field>
          </div>

          <div class="mb-3">
            <mat-form-field appearance="outline" class="w-100">
              <mat-label>Password</mat-label>
              <input matInput formControlName="password" type="password" placeholder="Enter password" />
              <mat-error *ngIf="loginForm.get('password')?.hasError('required')">Password is required</mat-error>
              <mat-error *ngIf="loginForm.get('password')?.hasError('minlength')">Password must be at least 4 characters</mat-error>
            </mat-form-field>
          </div>

          <button mat-raised-button color="primary" type="submit" class="w-100 py-2 fs-6 fw-bold rounded-3" [disabled]="loginForm.invalid || isLoading">
            <span *ngIf="!isLoading">Login</span>
            <div *ngIf="isLoading" class="d-flex align-items-center justify-content-center gap-2">
              <mat-spinner diameter="20" color="accent"></mat-spinner>
              <span>Logging in...</span>
            </div>
          </button>
        </form>

        <div class="text-center mt-4 pt-2 border-top">
          <p class="text-secondary small mb-0">Don't have an account? <a routerLink="/register" class="text-primary fw-bold text-decoration-none">Register here</a></p>
        </div>
      </div>
    </div>
  `
})
export class LoginComponent implements OnInit {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private notificationService = inject(NotificationService);

  isLoading = false;

  loginForm: FormGroup = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(4)]]
  });

  ngOnInit(): void {
    if (this.authService.isLoggedIn()) {
      this.authService.redirectUserByRole();
    }
  }

  onSubmit(): void {
    if (this.loginForm.invalid) return;

    this.isLoading = true;
    this.authService.login(this.loginForm.value).subscribe({
      next: () => {
        this.isLoading = false;
        this.notificationService.showSuccess('Logged in successfully!');
        this.authService.redirectUserByRole();
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }
}

import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/notification.service';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

function passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
  const password = control.get('password')?.value;
  const confirmPassword = control.get('confirmPassword')?.value;
  if (password && confirmPassword && password !== confirmPassword) {
    return { passwordMismatch: true };
  }
  return null;
}

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatFormFieldModule,
    MatProgressSpinnerModule
  ],
  template: `
    <div class="d-flex align-items-center justify-content-center min-vh-100 bg-light py-5">
      <div class="card shadow-lg border-0 rounded-4 p-4" style="max-width: 440px; width: 100%;">
        <div class="text-center mb-4">
          <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-2" style="width: 56px; height: 56px;">
            <i class="bi bi-person-plus-fill fs-2"></i>
          </div>
          <h3 class="fw-bold text-dark">Create Account</h3>
          <p class="text-secondary small">Register as a new library user</p>
        </div>

        <form [formGroup]="registerForm" (ngSubmit)="onSubmit()">
          <div class="mb-3">
            <mat-form-field appearance="outline" class="w-100">
              <mat-label>Email Address</mat-label>
              <input matInput formControlName="email" type="email" placeholder="user@gmail.com" />
              <mat-error *ngIf="registerForm.get('email')?.hasError('required')">Email is required</mat-error>
              <mat-error *ngIf="registerForm.get('email')?.hasError('email')">Enter a valid email address</mat-error>
            </mat-form-field>
          </div>

          <div class="mb-3">
            <mat-form-field appearance="outline" class="w-100">
              <mat-label>Password</mat-label>
              <input matInput formControlName="password" type="password" placeholder="Enter password" />
              <mat-error *ngIf="registerForm.get('password')?.hasError('required')">Password is required</mat-error>
              <mat-error *ngIf="registerForm.get('password')?.hasError('minlength')">Password must be at least 4 characters</mat-error>
            </mat-form-field>
          </div>

          <div class="mb-3">
            <mat-form-field appearance="outline" class="w-100">
              <mat-label>Confirm Password</mat-label>
              <input matInput formControlName="confirmPassword" type="password" placeholder="Re-enter password" />
              <mat-error *ngIf="registerForm.hasError('passwordMismatch')">Passwords do not match</mat-error>
            </mat-form-field>
          </div>

          <button mat-raised-button color="primary" type="submit" class="w-100 py-2 fs-6 fw-bold rounded-3" [disabled]="registerForm.invalid || isLoading">
            <span *ngIf="!isLoading">Register User</span>
            <div *ngIf="isLoading" class="d-flex align-items-center justify-content-center gap-2">
              <mat-spinner diameter="20" color="accent"></mat-spinner>
              <span>Registering...</span>
            </div>
          </button>
        </form>

        <div class="text-center mt-4 pt-2 border-top">
          <p class="text-secondary small mb-0">Already have an account? <a routerLink="/login" class="text-primary fw-bold text-decoration-none">Login here</a></p>
        </div>
      </div>
    </div>
  `
})
export class RegisterComponent {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private notificationService = inject(NotificationService);
  private router = inject(Router);

  isLoading = false;

  registerForm: FormGroup = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(4)]],
    confirmPassword: ['', [Validators.required]]
  }, { validators: passwordMatchValidator });

  onSubmit(): void {
    if (this.registerForm.invalid) return;

    this.isLoading = true;
    const { email, password } = this.registerForm.value;

    this.authService.register({ email, password }).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.notificationService.showSuccess(response || 'User Registered Successfully!');
        this.router.navigate(['/login']);
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }
}

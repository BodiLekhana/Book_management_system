import { Component, OnInit, ChangeDetectorRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { forkJoin, of, catchError, finalize, timeout } from 'rxjs';
import { BookService } from '../../../core/services/book.service';
import { BorrowService } from '../../../core/services/borrow.service';
import { FineService } from '../../../core/services/fine.service';
import { AuthService } from '../../../core/services/auth.service';
import { LoadingComponent } from '../../../shared/loading/loading';

@Component({
  selector: 'app-user-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, LoadingComponent],
  template: `
    <div class="container-fluid p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 class="fw-bold mb-1">User Dashboard</h2>
          <p class="text-secondary small mb-0">Welcome back, <span class="fw-semibold text-dark">{{ userEmail }}</span></p>
        </div>
      </div>

      <app-loading *ngIf="isLoading" message="Loading your dashboard statistics..."></app-loading>

      <div *ngIf="!isLoading">
        <!-- Stat Cards -->
        <div class="row g-4 mb-5">
          <div class="col-12 col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
              <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-secondary small fw-semibold text-uppercase">Available Books</div>
                  <div class="display-6 fw-bold text-primary mt-1">{{ totalBooks }}</div>
                </div>
                <div class="bg-primary-subtle text-primary p-3 rounded-circle fs-3">
                  <i class="bi bi-book"></i>
                </div>
              </div>
              <div class="card-footer bg-transparent border-0 px-4 pb-3">
                <a routerLink="/user/books" class="text-primary small text-decoration-none fw-semibold">Browse Books <i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
              <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-secondary small fw-semibold text-uppercase">My Borrowed Books</div>
                  <div class="display-6 fw-bold text-success mt-1">{{ myBorrowsCount }}</div>
                </div>
                <div class="bg-success-subtle text-success p-3 rounded-circle fs-3">
                  <i class="bi bi-journal-check"></i>
                </div>
              </div>
              <div class="card-footer bg-transparent border-0 px-4 pb-3">
                <a routerLink="/user/borrows" class="text-success small text-decoration-none fw-semibold">View History <i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
              <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-secondary small fw-semibold text-uppercase">Pending Books</div>
                  <div class="display-6 fw-bold text-warning mt-1">{{ pendingBorrowsCount }}</div>
                </div>
                <div class="bg-warning-subtle text-warning p-3 rounded-circle fs-3">
                  <i class="bi bi-hourglass-split"></i>
                </div>
              </div>
              <div class="card-footer bg-transparent border-0 px-4 pb-3">
                <a routerLink="/user/pending" class="text-warning small text-decoration-none fw-semibold">Return Pending <i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-xl-3">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
              <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-secondary small fw-semibold text-uppercase">My Fines</div>
                  <div class="display-6 fw-bold text-danger mt-1">{{ myFinesCount }}</div>
                </div>
                <div class="bg-danger-subtle text-danger p-3 rounded-circle fs-3">
                  <i class="bi bi-cash-stack"></i>
                </div>
              </div>
              <div class="card-footer bg-transparent border-0 px-4 pb-3">
                <a routerLink="/user/fines" class="text-danger small text-decoration-none fw-semibold">Pay Fines <i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>
        </div>

        <!-- Quick Actions Banner -->
        <div class="card border-0 bg-primary text-white rounded-4 shadow-sm p-4">
          <div class="row align-items-center">
            <div class="col-md-8">
              <h4 class="fw-bold mb-2">Looking for a book to read?</h4>
              <p class="mb-0 text-white-50">Explore our catalog of books across programming, science, fiction, and more. Borrow instantly!</p>
            </div>
            <div class="col-md-4 text-md-end mt-3 mt-md-0">
              <a routerLink="/user/books" class="btn btn-light text-primary font-weight-bold px-4 py-2 rounded-3">
                <i class="bi bi-search me-1"></i> Browse Catalog
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class UserDashboardComponent implements OnInit {
  private bookService = inject(BookService);
  private borrowService = inject(BorrowService);
  private fineService = inject(FineService);
  private authService = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);

  isLoading = true;
  totalBooks = 0;
  myBorrowsCount = 0;
  pendingBorrowsCount = 0;
  myFinesCount = 0;

  get userEmail(): string | null {
    return this.authService.getUserEmail();
  }

  ngOnInit(): void {
    forkJoin({
      books: this.bookService.getAllBooks().pipe(timeout(5000), catchError(() => of([]))),
      myBorrows: this.borrowService.getMyBooks().pipe(timeout(5000), catchError(() => of([]))),
      pending: this.borrowService.getPendingBorrows().pipe(timeout(5000), catchError(() => of([]))),
      fines: this.fineService.getMyFines().pipe(timeout(5000), catchError(() => of([])))
    }).pipe(
      finalize(() => {
        this.isLoading = false;
        this.cdr.markForCheck();
        this.cdr.detectChanges();
      })
    ).subscribe({
      next: (res) => {
        this.totalBooks = Array.isArray(res.books) ? res.books.length : 0;
        this.myBorrowsCount = Array.isArray(res.myBorrows) ? res.myBorrows.length : 0;
        this.pendingBorrowsCount = Array.isArray(res.pending) ? res.pending.length : 0;
        this.myFinesCount = Array.isArray(res.fines) ? res.fines.length : 0;
        this.cdr.markForCheck();
        this.cdr.detectChanges();
      }
    });
  }
}

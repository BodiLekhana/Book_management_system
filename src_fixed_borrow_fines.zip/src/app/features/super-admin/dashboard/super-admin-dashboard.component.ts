import { Component, OnInit, ChangeDetectorRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { forkJoin, of, catchError, finalize, timeout } from 'rxjs';
import { AdminService } from '../../../core/services/admin.service';
import { BookService } from '../../../core/services/book.service';
import { BorrowService } from '../../../core/services/borrow.service';
import { FineService } from '../../../core/services/fine.service';
import { LoadingComponent } from '../../../shared/loading/loading';

@Component({
  selector: 'app-super-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, LoadingComponent],
  template: `
    <div class="container-fluid p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 class="fw-bold mb-1">Super Admin Dashboard</h2>
          <p class="text-secondary small mb-0">Full System Overview & Executive Control</p>
        </div>
      </div>

      <app-loading *ngIf="isLoading" message="Loading Super Admin statistics..."></app-loading>

      <div *ngIf="!isLoading">
        <div class="row g-4 mb-5">
          <div class="col-12 col-sm-6 col-xl-4">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
              <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-secondary small fw-semibold text-uppercase">Total Users</div>
                  <div class="display-6 fw-bold text-primary mt-1">{{ totalUsers }}</div>
                </div>
                <div class="bg-primary-subtle text-primary p-3 rounded-circle fs-3">
                  <i class="bi bi-people-fill"></i>
                </div>
              </div>
              <div class="card-footer bg-transparent border-0 px-4 pb-3">
                <a routerLink="/super-admin/users" class="text-primary small text-decoration-none fw-semibold">View All Users <i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-xl-4">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
              <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-secondary small fw-semibold text-uppercase">Total Books</div>
                  <div class="display-6 fw-bold text-success mt-1">{{ totalBooks }}</div>
                </div>
                <div class="bg-success-subtle text-success p-3 rounded-circle fs-3">
                  <i class="bi bi-book"></i>
                </div>
              </div>
              <div class="card-footer bg-transparent border-0 px-4 pb-3">
                <a routerLink="/super-admin/books" class="text-success small text-decoration-none fw-semibold">View Catalog <i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-xl-4">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
              <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-secondary small fw-semibold text-uppercase">Total Borrows</div>
                  <div class="display-6 fw-bold text-warning mt-1">{{ totalBorrows }}</div>
                </div>
                <div class="bg-warning-subtle text-warning p-3 rounded-circle fs-3">
                  <i class="bi bi-card-checklist"></i>
                </div>
              </div>
              <div class="card-footer bg-transparent border-0 px-4 pb-3">
                <a routerLink="/super-admin/borrows" class="text-warning small text-decoration-none fw-semibold">Borrow Analytics <i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-xl-6">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
              <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-secondary small fw-semibold text-uppercase">Total Fines Issued</div>
                  <div class="display-6 fw-bold text-danger mt-1">{{ totalFines }}</div>
                </div>
                <div class="bg-danger-subtle text-danger p-3 rounded-circle fs-3">
                  <i class="bi bi-receipt"></i>
                </div>
              </div>
              <div class="card-footer bg-transparent border-0 px-4 pb-3">
                <a routerLink="/super-admin/fines" class="text-danger small text-decoration-none fw-semibold">Fine Records <i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-xl-6">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
              <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-secondary small fw-semibold text-uppercase">Total Fine Revenue / Amount</div>
                  <div class="display-6 fw-bold text-dark mt-1">₹{{ totalFineAmount || 0 }}</div>
                </div>
                <div class="bg-dark-subtle text-dark p-3 rounded-circle fs-3">
                  <i class="bi bi-currency-rupee"></i>
                </div>
              </div>
              <div class="card-footer bg-transparent border-0 px-4 pb-3">
                <a routerLink="/super-admin/fines" class="text-dark small text-decoration-none fw-semibold">Financial Breakdown <i class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>
        </div>

        <!-- Create Admins Quick Section -->
        <div class="card border-0 bg-dark text-white rounded-4 p-4 shadow-sm">
          <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
            <div>
              <h4 class="fw-bold mb-1"><i class="bi bi-shield-lock me-2 text-warning"></i> Administrative Privileges</h4>
              <p class="text-white-50 small mb-0">As a Super Admin, you can provision new Admin and Super Admin accounts.</p>
            </div>
            <a routerLink="/super-admin/create-admin" class="btn btn-warning font-weight-bold px-4 py-2 rounded-3 text-nowrap">
              <i class="bi bi-person-plus-fill me-1"></i> Create Admin Account
            </a>
          </div>
        </div>
      </div>
    </div>
  `
})
export class SuperAdminDashboardComponent implements OnInit {
  private adminService = inject(AdminService);
  private bookService = inject(BookService);
  private borrowService = inject(BorrowService);
  private fineService = inject(FineService);
  private cdr = inject(ChangeDetectorRef);

  isLoading = true;
  totalUsers = 0;
  totalBooks = 0;
  totalBorrows = 0;
  totalFines = 0;
  totalFineAmount = 0;

  ngOnInit(): void {
    forkJoin({
      totalUsers: this.adminService.getTotalUsers().pipe(timeout(5000), catchError(() => of(0))),
      books: this.bookService.getAllBooks().pipe(timeout(5000), catchError(() => of([]))),
      totalBorrows: this.borrowService.getTotalBorrows().pipe(timeout(5000), catchError(() => of(0))),
      totalFines: this.fineService.getTotalFines().pipe(timeout(5000), catchError(() => of(0))),
      fineAmount: this.fineService.getTotalFineAmount().pipe(timeout(5000), catchError(() => of(0)))
    }).pipe(
      finalize(() => {
        this.isLoading = false;
        this.cdr.markForCheck();
        this.cdr.detectChanges();
      })
    ).subscribe({
      next: (res) => {
        this.totalUsers = typeof res.totalUsers === 'number' ? res.totalUsers : 0;
        this.totalBooks = Array.isArray(res.books) ? res.books.length : 0;
        this.totalBorrows = typeof res.totalBorrows === 'number' ? res.totalBorrows : 0;
        this.totalFines = typeof res.totalFines === 'number' ? res.totalFines : 0;
        this.totalFineAmount = typeof res.fineAmount === 'number' ? res.fineAmount : 0;
        this.cdr.markForCheck();
        this.cdr.detectChanges();
      }
    });
  }
}

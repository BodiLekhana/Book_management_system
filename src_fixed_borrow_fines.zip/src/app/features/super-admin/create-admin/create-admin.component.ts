import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminService } from '../../../core/services/admin.service';
import { NotificationService } from '../../../core/services/notification.service';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-create-admin',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatFormFieldModule,
    MatProgressSpinnerModule
  ],
  template: `
    <div class="container-fluid p-4">
      <div class="mb-4">
        <h2 class="fw-bold mb-1">Provision Admin Accounts</h2>
        <p class="text-secondary small mb-0">Create new ADMIN or SUPER_ADMIN users with administrative access</p>
      </div>

      <div class="row g-4">
        <!-- Create ADMIN Form -->
        <div class="col-12 col-lg-6">
          <div class="card border-0 shadow-sm rounded-4 p-4 bg-white h-100">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="bg-warning-subtle text-warning p-3 rounded-circle fs-4">
                <i class="bi bi-person-gear"></i>
              </div>
              <div>
                <h4 class="fw-bold text-dark mb-0">Create Admin</h4>
                <p class="text-secondary small mb-0">Assign standard ADMIN role permissions</p>
              </div>
            </div>

            <form [formGroup]="adminForm" (ngSubmit)="onCreateAdmin()">
              <div class="mb-3">
                <mat-form-field appearance="outline" class="w-100">
                  <mat-label>Admin Email</mat-label>
                  <input matInput formControlName="email" type="email" placeholder="admin@gmail.com" />
                  <mat-error *ngIf="adminForm.get('email')?.hasError('required')">Email is required</mat-error>
                  <mat-error *ngIf="adminForm.get('email')?.hasError('email')">Valid email required</mat-error>
                </mat-form-field>
              </div>

              <div class="mb-4">
                <mat-form-field appearance="outline" class="w-100">
                  <mat-label>Password</mat-label>
                  <input matInput formControlName="password" type="password" placeholder="Enter password" />
                  <mat-error *ngIf="adminForm.get('password')?.hasError('required')">Password is required</mat-error>
                  <mat-error *ngIf="adminForm.get('password')?.hasError('minlength')">Min 4 characters</mat-error>
                </mat-form-field>
              </div>

              <button mat-raised-button color="primary" type="submit" class="w-100 py-2 fw-bold rounded-3" [disabled]="adminForm.invalid || isSubmittingAdmin">
                <span *ngIf="!isSubmittingAdmin"><i class="bi bi-shield-plus me-1"></i> Create Admin User</span>
                <span *ngIf="isSubmittingAdmin" class="spinner-border spinner-border-sm"></span>
              </button>
            </form>
          </div>
        </div>

        <!-- Create SUPER_ADMIN Form -->
        <div class="col-12 col-lg-6">
          <div class="card border-0 shadow-sm rounded-4 p-4 bg-white h-100">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="bg-danger-subtle text-danger p-3 rounded-circle fs-4">
                <i class="bi bi-shield-lock-fill"></i>
              </div>
              <div>
                <h4 class="fw-bold text-dark mb-0">Create Super Admin</h4>
                <p class="text-secondary small mb-0">Assign highest SUPER_ADMIN privileges</p>
              </div>
            </div>

            <form [formGroup]="superAdminForm" (ngSubmit)="onCreateSuperAdmin()">
              <div class="mb-3">
                <mat-form-field appearance="outline" class="w-100">
                  <mat-label>Super Admin Email</mat-label>
                  <input matInput formControlName="email" type="email" placeholder="superadmin@gmail.com" />
                  <mat-error *ngIf="superAdminForm.get('email')?.hasError('required')">Email is required</mat-error>
                  <mat-error *ngIf="superAdminForm.get('email')?.hasError('email')">Valid email required</mat-error>
                </mat-form-field>
              </div>

              <div class="mb-4">
                <mat-form-field appearance="outline" class="w-100">
                  <mat-label>Password</mat-label>
                  <input matInput formControlName="password" type="password" placeholder="Enter password" />
                  <mat-error *ngIf="superAdminForm.get('password')?.hasError('required')">Password is required</mat-error>
                  <mat-error *ngIf="superAdminForm.get('password')?.hasError('minlength')">Min 4 characters</mat-error>
                </mat-form-field>
              </div>

              <button mat-raised-button color="warn" type="submit" class="w-100 py-2 fw-bold rounded-3" [disabled]="superAdminForm.invalid || isSubmittingSuperAdmin">
                <span *ngIf="!isSubmittingSuperAdmin"><i class="bi bi-person-plus-fill me-1"></i> Create Super Admin</span>
                <span *ngIf="isSubmittingSuperAdmin" class="spinner-border spinner-border-sm"></span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CreateAdminComponent {
  private fb = inject(FormBuilder);
  private adminService = inject(AdminService);
  private notificationService = inject(NotificationService);

  isSubmittingAdmin = false;
  isSubmittingSuperAdmin = false;

  adminForm: FormGroup = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(4)]]
  });

  superAdminForm: FormGroup = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(4)]]
  });

  onCreateAdmin(): void {
    if (this.adminForm.invalid) return;

    this.isSubmittingAdmin = true;
    this.adminService.createAdmin(this.adminForm.value).subscribe({
      next: (res) => {
        this.isSubmittingAdmin = false;
        this.notificationService.showSuccess(res || 'Admin created successfully!');
        this.adminForm.reset();
      },
      error: () => {
        this.isSubmittingAdmin = false;
      }
    });
  }

  onCreateSuperAdmin(): void {
    if (this.superAdminForm.invalid) return;

    this.isSubmittingSuperAdmin = true;
    this.adminService.createSuperAdmin(this.superAdminForm.value).subscribe({
      next: (res) => {
        this.isSubmittingSuperAdmin = false;
        this.notificationService.showSuccess(res || 'Super Admin created successfully!');
        this.superAdminForm.reset();
      },
      error: () => {
        this.isSubmittingSuperAdmin = false;
      }
    });
  }
}

import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-loading',
  standalone: true,
  imports: [CommonModule, MatProgressSpinnerModule],
  template: `
    <div *ngIf="show" class="d-flex flex-column align-items-center justify-content-center py-5">
      <mat-spinner diameter="48" color="primary"></mat-spinner>
      <p class="text-secondary mt-3 fw-medium" *ngIf="message">{{ message }}</p>
    </div>
  `
})
export class LoadingComponent {
  @Input() show = true;
  @Input() message = 'Loading data...';
}

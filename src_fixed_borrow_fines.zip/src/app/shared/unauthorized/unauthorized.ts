import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-unauthorized',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container text-center py-5">
      <div class="display-1 text-danger fw-bold">403</div>
      <h2 class="fw-bold mb-3">Access Denied</h2>
      <p class="text-secondary mb-4">You do not have the required permissions to access this page.</p>
      <button class="btn btn-primary px-4 py-2" (click)="goHome()">Return to Dashboard</button>
    </div>
  `
})
export class UnauthorizedComponent {
  private authService = inject(AuthService);

  goHome(): void {
    this.authService.redirectUserByRole();
  }
}

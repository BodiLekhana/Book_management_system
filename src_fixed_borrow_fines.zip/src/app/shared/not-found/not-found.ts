import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="container text-center py-5">
      <div class="display-1 text-primary fw-bold">404</div>
      <h2 class="fw-bold mb-3">Page Not Found</h2>
      <p class="text-secondary mb-4">The page you are looking for does not exist or has been moved.</p>
      <a routerLink="/" class="btn btn-primary px-4 py-2">Go to Home</a>
    </div>
  `
})
export class NotFoundComponent {}

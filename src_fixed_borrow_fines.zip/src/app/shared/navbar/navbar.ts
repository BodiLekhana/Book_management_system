import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm px-3">
      <div class="container-fluid">
        <a class="navbar-brand d-flex align-items-center gap-2 font-weight-bold" (click)="authService.redirectUserByRole()" style="cursor: pointer;">
          <i class="bi bi-journal-bookmark-fill text-warning fs-4"></i>
          <span>Library Management System</span>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0" *ngIf="isLoggedIn">
            <!-- USER Links -->
            <ng-container *ngIf="userRole === 'USER'">
              <li class="nav-item">
                <a class="nav-link" routerLink="/user/dashboard" routerLinkActive="active"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/user/books" routerLinkActive="active"><i class="bi bi-book me-1"></i> Books</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/user/borrows" routerLinkActive="active"><i class="bi bi-clock-history me-1"></i> My Borrows</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/user/pending" routerLinkActive="active"><i class="bi bi-exclamation-circle me-1"></i> Pending Books</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/user/fines" routerLinkActive="active"><i class="bi bi-cash-stack me-1"></i> My Fines</a>
              </li>
            </ng-container>

            <!-- ADMIN Links -->
            <ng-container *ngIf="userRole === 'ADMIN'">
              <li class="nav-item">
                <a class="nav-link" routerLink="/admin/dashboard" routerLinkActive="active"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/admin/books" routerLinkActive="active"><i class="bi bi-book-half me-1"></i> Book Management</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/admin/users" routerLinkActive="active"><i class="bi bi-people me-1"></i> Users</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/admin/borrows" routerLinkActive="active"><i class="bi bi-arrow-left-right me-1"></i> Borrow Records</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/admin/fines" routerLinkActive="active"><i class="bi bi-receipt me-1"></i> Fine Management</a>
              </li>
            </ng-container>

            <!-- SUPER_ADMIN Links -->
            <ng-container *ngIf="userRole === 'SUPER_ADMIN'">
              <li class="nav-item">
                <a class="nav-link" routerLink="/super-admin/dashboard" routerLinkActive="active"><i class="bi bi-speedometer2 me-1"></i> Dashboard</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/super-admin/create-admin" routerLinkActive="active"><i class="bi bi-person-plus me-1"></i> Create Admin</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/super-admin/users" routerLinkActive="active"><i class="bi bi-people-fill me-1"></i> All Users</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/super-admin/books" routerLinkActive="active"><i class="bi bi-book me-1"></i> Books</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/super-admin/borrows" routerLinkActive="active"><i class="bi bi-card-checklist me-1"></i> All Borrows</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/super-admin/fines" routerLinkActive="active"><i class="bi bi-calculator me-1"></i> All Fines</a>
              </li>
            </ng-container>
          </ul>

          <div class="d-flex align-items-center gap-3 ms-auto" *ngIf="isLoggedIn; else loginButtons">
            <span class="text-light small">
              <i class="bi bi-person-circle me-1"></i> {{ userEmail }}
              <span class="badge ms-1" [ngClass]="{
                'bg-primary': userRole === 'USER',
                'bg-warning text-dark': userRole === 'ADMIN',
                'bg-danger': userRole === 'SUPER_ADMIN'
              }">{{ userRole }}</span>
            </span>
            <button class="btn btn-outline-light btn-sm" (click)="logout()">
              <i class="bi bi-box-arrow-right me-1"></i> Logout
            </button>
          </div>

          <ng-template #loginButtons>
            <div class="d-flex gap-2 ms-auto">
              <a routerLink="/login" class="btn btn-outline-light btn-sm">Login</a>
              <a routerLink="/register" class="btn btn-primary btn-sm">Register</a>
            </div>
          </ng-template>
        </div>
      </div>
    </nav>
  `
})
export class NavbarComponent {
  authService = inject(AuthService);

  get isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }

  get userEmail(): string | null {
    return this.authService.getUserEmail();
  }

  get userRole(): string | null {
    return this.authService.getRole();
  }

  logout(): void {
    this.authService.logout();
  }
}

import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <div class="bg-white border-end h-100 p-3 shadow-sm d-none d-md-block" style="min-width: 240px; max-width: 260px;">
      <div class="px-2 mb-4">
        <h6 class="text-uppercase text-secondary fw-bold small tracking-wide">Menu</h6>
      </div>

      <!-- USER MENU -->
      <div class="nav flex-column nav-pills" *ngIf="userRole === 'USER'">
        <a routerLink="/user/dashboard" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-speedometer2 text-primary"></i> Dashboard
        </a>
        <a routerLink="/user/books" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-book text-success"></i> Browse Books
        </a>
        <a routerLink="/user/borrows" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-journal-check text-info"></i> My Borrowed Books
        </a>
        <a routerLink="/user/pending" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-exclamation-triangle text-warning"></i> Pending Books
        </a>
        <a routerLink="/user/fines" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-cash text-danger"></i> My Fines
        </a>
      </div>

      <!-- ADMIN MENU -->
      <div class="nav flex-column nav-pills" *ngIf="userRole === 'ADMIN'">
        <a routerLink="/admin/dashboard" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-speedometer2 text-primary"></i> Admin Dashboard
        </a>
        <a routerLink="/admin/books" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-book-half text-success"></i> Book Management
        </a>
        <a routerLink="/admin/users" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-people text-info"></i> User Directory
        </a>
        <a routerLink="/admin/borrows" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-arrow-left-right text-warning"></i> Borrow Records
        </a>
        <a routerLink="/admin/fines" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-receipt text-danger"></i> Fine Management
        </a>
      </div>

      <!-- SUPER ADMIN MENU -->
      <div class="nav flex-column nav-pills" *ngIf="userRole === 'SUPER_ADMIN'">
        <a routerLink="/super-admin/dashboard" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-speedometer2 text-primary"></i> Super Admin Dashboard
        </a>
        <a routerLink="/super-admin/create-admin" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-person-plus text-primary"></i> Create Admin / Super Admin
        </a>
        <a routerLink="/super-admin/users" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-people-fill text-info"></i> Users Directory
        </a>
        <a routerLink="/super-admin/books" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-book text-success"></i> Book Catalog
        </a>
        <a routerLink="/super-admin/borrows" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-card-checklist text-warning"></i> Borrow Statistics
        </a>
        <a routerLink="/super-admin/fines" routerLinkActive="active" class="nav-link py-2.5 px-3 mb-1 text-dark d-flex align-items-center gap-2 rounded">
          <i class="bi bi-calculator text-danger"></i> Fine Statistics
        </a>
      </div>
    </div>
  `,
  styles: [`
    .nav-link.active {
      background-color: #e7f1ff !important;
      color: #0d6efd !important;
      font-weight: 600;
    }
  `]
})
export class SidebarComponent {
  private authService = inject(AuthService);

  get userRole(): string | null {
    return this.authService.getRole();
  }
}

import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { TokenService } from '../services/token.service';
import { NotificationService } from '../services/notification.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const tokenService = inject(TokenService);
  const notificationService = inject(NotificationService);
  const router = inject(Router);

  const token = tokenService.getToken();

  let clonedReq = req;
  if (token) {
    clonedReq = req.clone({
      headers: req.headers.set('Authorization', `Bearer ${token}`)
    });
  }

  return next(clonedReq).pipe(
    catchError((error: HttpErrorResponse) => {
      if (error.status === 401) {
        tokenService.removeToken();
        if (req.url.includes('/auth/login')) {
          notificationService.showError('Invalid email or password.');
        } else {
          notificationService.showError('Session expired. Please log in again.');
          router.navigate(['/login']);
        }
      } else if (error.status === 403) {
        notificationService.showError('Access Denied: You do not have permission for this resource.');
      } else if (error.status === 400) {
        const errorMsg = typeof error.error === 'string' ? error.error : (error.error?.message || 'Invalid request parameters.');
        notificationService.showError(errorMsg);
      } else if (error.status === 404) {
        notificationService.showError('Resource not found.');
      } else if (error.status >= 500) {
        notificationService.showError('Server error occurred. Please try again later.');
      } else {
        notificationService.showError('An unexpected error occurred.');
      }

      return throwError(() => error);
    })
  );
};

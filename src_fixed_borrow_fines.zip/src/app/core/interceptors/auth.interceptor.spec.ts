import { TestBed } from '@angular/core/testing';
import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { authInterceptor } from './auth.interceptor';
import { TokenService } from '../services/token.service';
import { NotificationService } from '../services/notification.service';

describe('authInterceptor', () => {
  let httpClient: HttpClient;
  let httpMock: HttpTestingController;
  let tokenServiceMock: any;
  let routerMock: any;

  beforeEach(() => {
    tokenServiceMock = {
      getToken: vi.fn(),
      removeToken: vi.fn()
    };
    routerMock = {
      navigate: vi.fn()
    };

    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([authInterceptor])),
        provideHttpClientTesting(),
        { provide: TokenService, useValue: tokenServiceMock },
        { provide: Router, useValue: routerMock },
        NotificationService
      ]
    });

    httpClient = TestBed.inject(HttpClient);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should attach Bearer token to Authorization header when token exists', () => {
    tokenServiceMock.getToken.mockReturnValue('my-jwt-token');

    httpClient.get('http://localhost:8085/test-api').subscribe();

    const req = httpMock.expectOne('http://localhost:8085/test-api');
    expect(req.request.headers.has('Authorization')).toBe(true);
    expect(req.request.headers.get('Authorization')).toBe('Bearer my-jwt-token');
  });

  it('should handle 401 error by clearing token and redirecting to login', () => {
    tokenServiceMock.getToken.mockReturnValue('expired-jwt-token');

    httpClient.get('http://localhost:8085/protected-api').subscribe({
      next: () => {},
      error: (err) => {
        expect(err.status).toBe(401);
      }
    });

    const req = httpMock.expectOne('http://localhost:8085/protected-api');
    req.flush('Unauthorized', { status: 401, statusText: 'Unauthorized' });

    expect(tokenServiceMock.removeToken).toHaveBeenCalled();
    expect(routerMock.navigate).toHaveBeenCalledWith(['/login']);
  });
});

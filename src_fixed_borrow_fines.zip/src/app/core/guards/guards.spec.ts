import { TestBed } from '@angular/core/testing';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { authGuard } from './auth.guard';
import { roleGuard } from './role.guard';
import { AuthService } from '../services/auth.service';
import { NotificationService } from '../services/notification.service';

describe('Route Guards', () => {
  let authServiceMock: any;
  let routerMock: any;
  let notificationServiceMock: any;

  beforeEach(() => {
    authServiceMock = {
      isLoggedIn: vi.fn(),
      getRole: vi.fn()
    };
    routerMock = {
      navigate: vi.fn()
    };
    notificationServiceMock = {
      showError: vi.fn()
    };

    TestBed.configureTestingModule({
      providers: [
        { provide: AuthService, useValue: authServiceMock },
        { provide: Router, useValue: routerMock },
        { provide: NotificationService, useValue: notificationServiceMock }
      ]
    });
  });

  describe('authGuard', () => {
    it('should allow access if user is logged in', () => {
      authServiceMock.isLoggedIn.mockReturnValue(true);
      const dummyRoute = {} as ActivatedRouteSnapshot;
      const dummyState = { url: '/user/dashboard' } as RouterStateSnapshot;

      const result = TestBed.runInInjectionContext(() => authGuard(dummyRoute, dummyState));
      expect(result).toBe(true);
    });

    it('should block access and redirect to login if user is not logged in', () => {
      authServiceMock.isLoggedIn.mockReturnValue(false);
      const dummyRoute = {} as ActivatedRouteSnapshot;
      const dummyState = { url: '/user/dashboard' } as RouterStateSnapshot;

      const result = TestBed.runInInjectionContext(() => authGuard(dummyRoute, dummyState));
      expect(result).toBe(false);
      expect(routerMock.navigate).toHaveBeenCalledWith(['/login'], { queryParams: { returnUrl: '/user/dashboard' } });
    });
  });

  describe('roleGuard', () => {
    it('should allow access if user role matches allowed roles', () => {
      authServiceMock.getRole.mockReturnValue('ADMIN');
      const dummyRoute = { data: { roles: ['ADMIN', 'SUPER_ADMIN'] } } as unknown as ActivatedRouteSnapshot;
      const dummyState = { url: '/admin/dashboard' } as RouterStateSnapshot;

      const result = TestBed.runInInjectionContext(() => roleGuard(dummyRoute, dummyState));
      expect(result).toBe(true);
    });

    it('should block access and redirect to /unauthorized if role does not match', () => {
      authServiceMock.getRole.mockReturnValue('USER');
      const dummyRoute = { data: { roles: ['ADMIN'] } } as unknown as ActivatedRouteSnapshot;
      const dummyState = { url: '/admin/dashboard' } as RouterStateSnapshot;

      const result = TestBed.runInInjectionContext(() => roleGuard(dummyRoute, dummyState));
      expect(result).toBe(false);
      expect(routerMock.navigate).toHaveBeenCalledWith(['/unauthorized']);
    });
  });
});

import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { NotificationService } from '../services/notification.service';

export const roleGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  const notificationService = inject(NotificationService);

  const allowedRoles = route.data['roles'] as Array<string>;
  const userRole = authService.getRole();

  if (userRole && allowedRoles && allowedRoles.includes(userRole)) {
    return true;
  }

  notificationService.showError('Access Denied: You do not have permission to access this area.');
  router.navigate(['/unauthorized']);
  return false;
};

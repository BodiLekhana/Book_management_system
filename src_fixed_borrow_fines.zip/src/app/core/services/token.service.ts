import { Injectable } from '@angular/core';
import { jwtDecode } from 'jwt-decode';
import { DecodedToken } from '../models/auth.model';

@Injectable({
  providedIn: 'root'
})
export class TokenService {
  private readonly TOKEN_KEY = 'auth_token';

  saveToken(token: string): void {
    localStorage.setItem(this.TOKEN_KEY, token);
  }

  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  removeToken(): void {
    localStorage.removeItem(this.TOKEN_KEY);
  }

  getDecodedToken(): DecodedToken | null {
    const token = this.getToken();
    if (!token) {
      return null;
    }
    try {
      return jwtDecode<DecodedToken>(token);
    } catch (e) {
      console.error('Failed to decode token:', e);
      return null;
    }
  }

  getUserEmail(): string | null {
    const decoded = this.getDecodedToken();
    if (!decoded) return null;
    return decoded.email || decoded.sub || null;
  }

  getUserRole(): string | null {
    const decoded = this.getDecodedToken();
    if (!decoded) return null;

    let rawRole: any;

    if (decoded.role) {
      rawRole = decoded.role;
    } else if (Array.isArray(decoded.roles) && decoded.roles.length > 0) {
      rawRole = decoded.roles[0];
    } else if (decoded.roles) {
      rawRole = decoded.roles;
    } else if (Array.isArray(decoded.authorities) && decoded.authorities.length > 0) {
      rawRole = decoded.authorities[0];
    } else if (decoded.authorities) {
      rawRole = decoded.authorities;
    }

    if (!rawRole) return null;

    let roleStr = '';
    if (typeof rawRole === 'string') {
      roleStr = rawRole;
    } else if (typeof rawRole === 'object' && rawRole !== null) {
      roleStr = rawRole.authority || rawRole.role || rawRole.name || '';
    }

    if (!roleStr) return null;

    const cleanRole = roleStr.toUpperCase().replace(/^ROLE_/, '');
    return cleanRole;
  }

  isTokenExpired(): boolean {
    const decoded = this.getDecodedToken();
    if (!decoded || !decoded.exp) {
      return false; // If exp not present, assume active if token exists
    }
    const currentTime = Math.floor(Date.now() / 1000);
    return decoded.exp < currentTime;
  }
}

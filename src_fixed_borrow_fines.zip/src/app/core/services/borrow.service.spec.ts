import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { BorrowService } from './borrow.service';
import { BorrowRecord } from '../models/borrow-record.model';
import { environment } from '../../../environments/environment';

describe('BorrowService', () => {
  let service: BorrowService;
  let httpMock: HttpTestingController;

  const mockRecords: BorrowRecord[] = [
    { id: 1, bookId: 5, userEmail: 'user@gmail.com', borrowDate: '2026-09-20', dueDate: '2026-09-27', returnDate: null, returned: false }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BorrowService]
    });

    service = TestBed.inject(BorrowService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should borrow book via POST /borrow/{bookId}', () => {
    service.borrowBook(5).subscribe((res) => {
      expect(res).toEqual(mockRecords[0]);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/borrow/5`);
    expect(req.request.method).toBe('POST');
    req.flush(mockRecords[0]);
  });

  it('should return book via PUT /borrow/return/{id}', () => {
    service.returnBook(1).subscribe((res) => {
      expect(res).toBe('Book returned successfully');
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/borrow/return/1`);
    expect(req.request.method).toBe('PUT');
    req.flush('Book returned successfully');
  });

  it('should fetch user borrows via GET /borrow/my-books', () => {
    service.getMyBooks().subscribe((res) => {
      expect(res).toEqual(mockRecords);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/borrow/my-books`);
    expect(req.request.method).toBe('GET');
    req.flush(mockRecords);
  });

  it('should fetch pending borrows via GET /borrow/pending', () => {
    service.getPendingBorrows().subscribe((res) => {
      expect(res).toEqual(mockRecords);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/borrow/pending`);
    expect(req.request.method).toBe('GET');
    req.flush(mockRecords);
  });

  it('should fetch all records via GET /borrow/all', () => {
    service.getAllRecords().subscribe((res) => {
      expect(res).toEqual(mockRecords);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/borrow/all`);
    expect(req.request.method).toBe('GET');
    req.flush(mockRecords);
  });
});

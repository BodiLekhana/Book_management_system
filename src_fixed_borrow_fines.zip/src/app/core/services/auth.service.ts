import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, BehaviorSubject, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { LoginRequest, RegisterRequest, AuthResponse } from '../models/auth.model';
import { TokenService } from './token.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private http = inject(HttpClient);
  private tokenService = inject(TokenService);
  private router = inject(Router);

  private authUrl = `${environment.apiUrl}/auth`;
  private currentUserSubject = new BehaviorSubject<string | null>(this.tokenService.getUserEmail());
  public currentUser$ = this.currentUserSubject.asObservable();

  register(request: RegisterRequest): Observable<string> {
    return this.http.post(`${this.authUrl}/register`, request, { responseType: 'text' });
  }

  login(request: LoginRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.authUrl}/login`, request).pipe(
      tap((res) => {
        if (res && res.token) {
          this.tokenService.saveToken(res.token);
          this.currentUserSubject.next(this.tokenService.getUserEmail());
        }
      })
    );
  }

  logout(): void {
    this.tokenService.removeToken();
    this.currentUserSubject.next(null);
    this.router.navigate(['/login']);
  }

  isLoggedIn(): boolean {
    const token = this.tokenService.getToken();
    return !!token && !this.tokenService.isTokenExpired();
  }

  getRole(): string | null {
    return this.tokenService.getUserRole();
  }

  getUserEmail(): string | null {
    return this.tokenService.getUserEmail();
  }

  redirectUserByRole(): void {
    const role = this.getRole();
    if (role === 'SUPER_ADMIN') {
      this.router.navigate(['/super-admin/dashboard']);
    } else if (role === 'ADMIN') {
      this.router.navigate(['/admin/dashboard']);
    } else if (role === 'USER') {
      this.router.navigate(['/user/dashboard']);
    } else {
      this.router.navigate(['/login']);
    }
  }
}

import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { RegisterRequest } from '../models/auth.model';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private http = inject(HttpClient);
  private adminUrl = `${environment.apiUrl}/admin`;

  createAdmin(request: RegisterRequest): Observable<string> {
    return this.http.post(`${this.adminUrl}/create-admin`, request, { responseType: 'text' });
  }

  createSuperAdmin(request: RegisterRequest): Observable<string> {
    return this.http.post(`${this.adminUrl}/create-super-admin`, request, { responseType: 'text' });
  }

  getTotalUsers(): Observable<number> {
    return this.http.get<number>(`${this.adminUrl}/total-users`);
  }

  getAllUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.adminUrl}/users`);
  }
}

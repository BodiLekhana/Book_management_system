import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { BookService } from './book.service';
import { Book } from '../models/book.model';
import { environment } from '../../../environments/environment';

describe('BookService', () => {
  let service: BookService;
  let httpMock: HttpTestingController;

  const mockBooks: Book[] = [
    { id: 1, title: 'Clean Code', author: 'Robert C. Martin', category: 'Programming', price: 500, quantity: 10 },
    { id: 2, title: 'Design Patterns', author: 'Gang of Four', category: 'Architecture', price: 750, quantity: 5 }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BookService]
    });

    service = TestBed.inject(BookService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should fetch all books via GET /books', () => {
    service.getAllBooks().subscribe((books) => {
      expect(books.length).toBe(2);
      expect(books).toEqual(mockBooks);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/books`);
    expect(req.request.method).toBe('GET');
    req.flush(mockBooks);
  });

  it('should fetch book by ID via GET /books/{id}', () => {
    service.getBookById(1).subscribe((book) => {
      expect(book).toEqual(mockBooks[0]);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/books/1`);
    expect(req.request.method).toBe('GET');
    req.flush(mockBooks[0]);
  });

  it('should add a book via POST /books/add', () => {
    const newBook: Book = { title: 'Refactoring', author: 'Martin Fowler', category: 'Programming', price: 600, quantity: 8 };

    service.addBook(newBook).subscribe((res) => {
      expect(res).toEqual({ id: 3, ...newBook });
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/books/add`);
    expect(req.request.method).toBe('POST');
    req.flush({ id: 3, ...newBook });
  });

  it('should update a book via PUT /books/{id}', () => {
    const updatedBook: Book = { id: 1, title: 'Clean Code 2nd Ed', author: 'Robert C. Martin', category: 'Programming', price: 550, quantity: 12 };

    service.updateBook(1, updatedBook).subscribe((res) => {
      expect(res).toEqual(updatedBook);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/books/1`);
    expect(req.request.method).toBe('PUT');
    req.flush(updatedBook);
  });

  it('should delete a book via DELETE /books/{id}', () => {
    service.deleteBook(1).subscribe((res) => {
      expect(res).toBe('Book Deleted');
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/books/1`);
    expect(req.request.method).toBe('DELETE');
    req.flush('Book Deleted');
  });
});

import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { BorrowRecord } from '../models/borrow-record.model';

@Injectable({
  providedIn: 'root'
})
export class BorrowService {
  private http = inject(HttpClient);
  private borrowUrl = `${environment.apiUrl}/borrow`;

  borrowBook(bookId: number): Observable<BorrowRecord> {
    return this.http.post<BorrowRecord>(`${this.borrowUrl}/${bookId}`, {});
  }

  returnBook(borrowId: number): Observable<string> {
    return this.http.put(`${this.borrowUrl}/return/${borrowId}`, {}, { responseType: 'text' });
  }

  getMyBooks(): Observable<BorrowRecord[]> {
    return this.http.get<BorrowRecord[]>(`${this.borrowUrl}/my-books`);
  }

  getPendingBorrows(): Observable<BorrowRecord[]> {
    return this.http.get<BorrowRecord[]>(`${this.borrowUrl}/pending`);
  }

  getAllRecords(): Observable<BorrowRecord[]> {
    return this.http.get<BorrowRecord[]>(`${this.borrowUrl}/all`);
  }

  getTotalBorrows(): Observable<number> {
    return this.http.get<number>(`${this.borrowUrl}/count`);
  }
}

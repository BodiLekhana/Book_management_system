import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Fine } from '../models/fine.model';

@Injectable({
  providedIn: 'root'
})
export class FineService {
  private http = inject(HttpClient);
  private finesUrl = `${environment.apiUrl}/fines`;

  createFine(email: string, borrowId: number, amount: number): Observable<Fine> {
    const params = new HttpParams()
      .set('email', email)
      .set('borrowId', borrowId.toString())
      .set('amount', amount.toString());

    return this.http.post<Fine>(`${this.finesUrl}/create`, null, { params });
  }

  getMyFines(): Observable<Fine[]> {
    return this.http.get<Fine[]>(`${this.finesUrl}/my`);
  }

  getAllFines(): Observable<Fine[]> {
    return this.http.get<Fine[]>(`${this.finesUrl}/all`);
  }

  payFine(id: number): Observable<Blob> {
    return this.http.get(`${this.finesUrl}/pay/${id}`, {
      responseType: 'blob'
    });
  }

  getTotalFines(): Observable<number> {
    return this.http.get<number>(`${this.finesUrl}/count`);
  }

  getTotalFineAmount(): Observable<number> {
    return this.http.get<number>(`${this.finesUrl}/amount`);
  }
}

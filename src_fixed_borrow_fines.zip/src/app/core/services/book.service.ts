import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Book } from '../models/book.model';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  private http = inject(HttpClient);
  private booksUrl = `${environment.apiUrl}/books`;

  getAllBooks(): Observable<Book[]> {
    return this.http.get<Book[]>(this.booksUrl);
  }

  getBookById(id: number): Observable<Book> {
    return this.http.get<Book>(`${this.booksUrl}/${id}`);
  }

  addBook(book: Book): Observable<Book> {
    return this.http.post<Book>(`${this.booksUrl}/add`, book);
  }

  updateBook(id: number, book: Book): Observable<Book> {
    return this.http.put<Book>(`${this.booksUrl}/${id}`, book);
  }

  deleteBook(id: number): Observable<string> {
    return this.http.delete(`${this.booksUrl}/${id}`, { responseType: 'text' });
  }

  reduceBookQuantity(id: number): Observable<string> {
    return this.http.put(`${this.booksUrl}/reduce/${id}`, {}, { responseType: 'text' });
  }

  increaseBookQuantity(id: number): Observable<string> {
    return this.http.put(`${this.booksUrl}/increase/${id}`, {}, { responseType: 'text' });
  }
}

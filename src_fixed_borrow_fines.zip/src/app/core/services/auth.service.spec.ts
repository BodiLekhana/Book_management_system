import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';
import { TokenService } from './token.service';
import { environment } from '../../../environments/environment';

describe('AuthService', () => {
  let service: AuthService;
  let httpMock: HttpTestingController;
  let tokenService: TokenService;
  let routerMock: any;

  beforeEach(() => {
    routerMock = {
      navigate: vi.fn()
    };

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        AuthService,
        TokenService,
        { provide: Router, useValue: routerMock }
      ]
    });

    service = TestBed.inject(AuthService);
    httpMock = TestBed.inject(HttpTestingController);
    tokenService = TestBed.inject(TokenService);
  });

  afterEach(() => {
    httpMock.verify();
    localStorage.clear();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should register a new user via POST /auth/register', () => {
    const registerData = { email: 'user@gmail.com', password: 'password' };
    const mockResponse = 'User Registered Successfully';

    service.register(registerData).subscribe((res) => {
      expect(res).toBe(mockResponse);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/auth/register`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(registerData);
    req.flush(mockResponse);
  });

  it('should login user, store token and update current user', () => {
    const loginData = { email: 'user@gmail.com', password: 'password' };
    const mockResponse = { token: 'mock-jwt-token' };

    vi.spyOn(tokenService, 'saveToken');
    vi.spyOn(tokenService, 'getUserEmail').mockReturnValue('user@gmail.com');

    service.login(loginData).subscribe((res) => {
      expect(res).toEqual(mockResponse);
      expect(tokenService.saveToken).toHaveBeenCalledWith('mock-jwt-token');
      expect(service.getUserEmail()).toBe('user@gmail.com');
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/auth/login`);
    expect(req.request.method).toBe('POST');
    req.flush(mockResponse);
  });

  it('should remove token and navigate to /login on logout', () => {
    vi.spyOn(tokenService, 'removeToken');

    service.logout();

    expect(tokenService.removeToken).toHaveBeenCalled();
    expect(routerMock.navigate).toHaveBeenCalledWith(['/login']);
  });

  it('should check if logged in based on token validity', () => {
    vi.spyOn(tokenService, 'getToken').mockReturnValue('valid-token');
    vi.spyOn(tokenService, 'isTokenExpired').mockReturnValue(false);

    expect(service.isLoggedIn()).toBe(true);
  });
});

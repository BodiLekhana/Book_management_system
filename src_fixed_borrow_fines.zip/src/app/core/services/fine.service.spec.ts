import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FineService } from './fine.service';
import { Fine } from '../models/fine.model';
import { environment } from '../../../environments/environment';

describe('FineService', () => {
  let service: FineService;
  let httpMock: HttpTestingController;

  const mockFines: Fine[] = [
    { id: 1, userEmail: 'user@gmail.com', borrowId: 5, amount: 100, paid: false }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [FineService]
    });

    service = TestBed.inject(FineService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should create fine via POST /fines/create query params', () => {
    service.createFine('user@gmail.com', 5, 100).subscribe((res) => {
      expect(res).toEqual(mockFines[0]);
    });

    const req = httpMock.expectOne((r) => r.url === `${environment.apiUrl}/fines/create`);
    expect(req.request.method).toBe('POST');
    expect(req.request.params.get('email')).toBe('user@gmail.com');
    expect(req.request.params.get('borrowId')).toBe('5');
    expect(req.request.params.get('amount')).toBe('100');
    req.flush(mockFines[0]);
  });

  it('should fetch user fines via GET /fines/my', () => {
    service.getMyFines().subscribe((res) => {
      expect(res).toEqual(mockFines);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/fines/my`);
    expect(req.request.method).toBe('GET');
    req.flush(mockFines);
  });

  it('should pay fine and download receipt via GET /fines/pay/{id}', () => {
    const mockBlob = new Blob(['PDF CONTENT'], { type: 'application/pdf' });

    service.payFine(1).subscribe((res) => {
      expect(res).toEqual(mockBlob);
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/fines/pay/1`);
    expect(req.request.method).toBe('GET');
    expect(req.request.responseType).toBe('blob');
    req.flush(mockBlob);
  });
});

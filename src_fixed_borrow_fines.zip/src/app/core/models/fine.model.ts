export interface Fine {
  id?: number;
  userEmail: string;
  borrowId: number;
  amount: number;
  paid: boolean;
}

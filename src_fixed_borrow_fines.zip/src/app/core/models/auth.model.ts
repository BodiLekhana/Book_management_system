export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  email: string;
  password: string;
}

export interface AuthResponse {
  token: string;
}

export interface DecodedToken {
  sub?: string;
  email?: string;
  role?: string;
  roles?: string[] | string;
  authorities?: string[] | string;
  exp?: number;
  iat?: number;
  [key: string]: any;
}

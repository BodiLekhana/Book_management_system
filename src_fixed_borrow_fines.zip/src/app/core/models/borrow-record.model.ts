export interface BorrowRecord {
  id?: number;
  bookId: number;
  userEmail: string;
  borrowDate: string;
  dueDate: string;
  returnDate?: string | null;
  returned: boolean;
}

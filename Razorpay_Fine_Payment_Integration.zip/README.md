# Razorpay fine-payment integration (test mode first)

This bundle updates the existing Fine Service and Angular `src` folder. The API Gateway already routes `/fines/**` to `FINE-SERVICE`, so no gateway route change is required.

## 1. Configure Razorpay credentials

Create or use a Razorpay account in **Test Mode** and obtain the Test Key ID and Key Secret. Do not put the secret in Angular, GitHub, or a source file.

Set these environment variables for the Fine Service process:

- `RAZORPAY_KEY_ID=rzp_test_...`
- `RAZORPAY_KEY_SECRET=...`

For Eclipse: **Run Configurations → your FineServiceApplication → Environment** and add both variables, then restart the Fine Service. The properties file reads these environment variables.

## 2. Replace source files

- Replace your existing Fine Service project source with the `fine_service/` folder in this bundle (retain your local deployment-specific database URL/credentials if they differ).
- Copy the `angular_src/src/` contents into the `src/` folder of your Angular project, replacing the corresponding files. The frontend continues to call the API Gateway at `http://localhost:8085` via its existing environment configuration.
- The existing gateway route `Path=/fines/**` already covers the payment endpoints.

## 3. Payment flow

1. The signed-in user clicks **Pay Now** for an unpaid fine.
2. Fine Service reads the fine amount from the database and creates a Razorpay order server-side.
3. Razorpay Checkout opens in Angular.
4. Angular sends the Checkout order/payment/signature response to Fine Service.
5. Fine Service checks that the signed-in user owns the fine, validates the HMAC signature, fetches payment details from Razorpay, checks order/amount/currency, and captures an authorized payment if needed.
6. The fine becomes `paid=true` only after Razorpay reports `captured`.
7. The user can download the PDF receipt only after payment has been verified.

## 4. Endpoints added

- `POST /fines/payment/order/{fineId}` — authenticated USER; creates an order for that user's fine.
- `POST /fines/payment/verify` — authenticated USER; verifies Checkout response and confirms captured payment.
- `GET /fines/pay/{fineId}` — now only downloads a PDF receipt for a paid fine; it no longer marks a fine paid.

All calls should go through the gateway, e.g. `http://localhost:8085/fines/payment/order/2`, and include the JWT `Authorization: Bearer <token>` header. Manual fine creation is intended for ADMIN/SUPER_ADMIN. A USER JWT is accepted only for that same email to preserve the existing Borrow Service late-return workflow that forwards the borrower token.

## 5. Important notes

- The database will be updated automatically by Hibernate with nullable `razorpay_order_id` and `razorpay_payment_id` columns.
- Keep the Razorpay secret only on the backend. The key ID is returned to Angular because Checkout needs it.
- Use test credentials and test payments before considering live mode. Configure Razorpay webhooks and operational reconciliation before production deployment; client callbacks alone are not a substitute for a webhook-based recovery path.
- Maven was not available in the build environment used to prepare this bundle, so run `mvn clean package` in the Fine Service project and resolve any local environment/dependency issues before starting it.

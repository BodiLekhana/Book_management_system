package service;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import dto.RazorpayOrderResponse;
import dto.VerifyPaymentRequest;
import entity.Fine;
import repository.FineRepository;

@Service
public class FineService {
    private static final Logger logger = LoggerFactory.getLogger(FineService.class);
    private final FineRepository repository;
    private final PdfService pdfService;
    private final RazorpayService razorpayService;

    @Value("${razorpay.key-id:}")
    private String razorpayKeyId;

    public FineService(FineRepository repository, PdfService pdfService, RazorpayService razorpayService) {
        this.repository = repository;
        this.pdfService = pdfService;
        this.razorpayService = razorpayService;
    }

    public Fine createFine(String email, Long borrowId, double amount) {
        if (email == null || email.isBlank() || borrowId == null || !Double.isFinite(amount) || amount <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "A valid email, borrow ID and positive amount are required");
        }
        logger.info("Creating fine for borrow record {}", borrowId);
        Fine fine = new Fine();
        fine.setUserEmail(email);
        fine.setBorrowId(borrowId);
        fine.setAmount(BigDecimal.valueOf(amount).setScale(2, RoundingMode.HALF_UP).doubleValue());
        fine.setPaid(false);
        return repository.save(fine);
    }

    public List<Fine> myFines(String email) { return repository.findByUserEmail(email); }
    public List<Fine> allFines() { return repository.findAll(); }

    @Transactional
    public RazorpayOrderResponse createPaymentOrder(Long fineId, String currentUserEmail) {
        Fine fine = getOwnedFine(fineId, currentUserEmail);
        if (fine.isPaid()) throw new ResponseStatusException(HttpStatus.CONFLICT, "This fine has already been paid");
        long paise = BigDecimal.valueOf(fine.getAmount()).multiply(BigDecimal.valueOf(100))
                .setScale(0, RoundingMode.HALF_UP).longValueExact();
        String orderId = razorpayService.createOrder(paise, "fine_" + fine.getId(), fine.getId(), fine.getUserEmail());
        fine.setRazorpayOrderId(orderId);
        repository.save(fine);
        return new RazorpayOrderResponse(fine.getId(), razorpayKeyId, orderId, paise, "INR", fine.getUserEmail());
    }

    @Transactional
    public Fine verifyPayment(VerifyPaymentRequest request, String currentUserEmail) {
        if (request == null || request.getFineId() == null || blank(request.getRazorpayOrderId())
                || blank(request.getRazorpayPaymentId()) || blank(request.getRazorpaySignature())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Missing payment verification fields");
        }
        Fine fine = getOwnedFine(request.getFineId(), currentUserEmail);
        if (fine.isPaid()) {
            if (request.getRazorpayPaymentId().equals(fine.getRazorpayPaymentId())) return fine;
            throw new ResponseStatusException(HttpStatus.CONFLICT, "This fine has already been paid");
        }
        if (fine.getRazorpayOrderId() == null || !fine.getRazorpayOrderId().equals(request.getRazorpayOrderId())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "The Razorpay order does not belong to this fine");
        }
        razorpayService.verifySignature(request.getRazorpayOrderId(), request.getRazorpayPaymentId(), request.getRazorpaySignature());
        Map<String, Object> payment = razorpayService.fetchPayment(request.getRazorpayPaymentId());
        if (payment == null || !request.getRazorpayOrderId().equals(String.valueOf(payment.get("order_id")))) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Payment is not associated with this order");
        }
        long expectedPaise = BigDecimal.valueOf(fine.getAmount()).multiply(BigDecimal.valueOf(100))
                .setScale(0, RoundingMode.HALF_UP).longValueExact();
        Object amountValue = payment.get("amount");
        if (!(amountValue instanceof Number) || ((Number) amountValue).longValue() != expectedPaise
                || !"INR".equals(payment.get("currency"))) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Payment amount or currency does not match this fine");
        }
        String paymentStatus = String.valueOf(payment.get("status"));
        if ("authorized".equalsIgnoreCase(paymentStatus)) {
            payment = razorpayService.capturePayment(request.getRazorpayPaymentId(), expectedPaise);
            paymentStatus = payment == null ? "unknown" : String.valueOf(payment.get("status"));
        }
        if (!"captured".equalsIgnoreCase(paymentStatus)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Payment has not been captured yet. Fine remains unpaid.");
        }
        fine.setRazorpayPaymentId(request.getRazorpayPaymentId());
        fine.setPaid(true);
        Fine saved = repository.save(fine);
        logger.info("Verified captured Razorpay payment for fine {}", fine.getId());
        return saved;
    }

    public ByteArrayInputStream receipt(Long id, String currentUserEmail) {
        Fine fine = getOwnedFine(id, currentUserEmail);
        if (!fine.isPaid()) throw new ResponseStatusException(HttpStatus.CONFLICT, "Receipt is available only after successful payment");
        return pdfService.generateReceipt(fine);
    }

    private Fine getOwnedFine(Long id, String email) {
        Fine fine = repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Fine not found"));
        if (email == null || !fine.getUserEmail().equalsIgnoreCase(email)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You cannot access another user's fine");
        }
        return fine;
    }
    private boolean blank(String value) { return value == null || value.isBlank(); }

    public long totalFines() { return repository.count(); }
    public Double totalFineAmount() { return repository.getTotalFineAmount(); }
}

package service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

@Service
public class RazorpayService {
    private static final String API_BASE = "https://api.razorpay.com/v1";
    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${razorpay.key-id:}")
    private String keyId;
    @Value("${razorpay.key-secret:}")
    private String keySecret;

    public String createOrder(long amountInPaise, String receipt, Long fineId, String email) {
        requireCredentials();
        HttpHeaders headers = authHeaders();
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("amount", amountInPaise);
        body.put("currency", "INR");
        body.put("receipt", receipt);
        body.put("notes", Map.of("fineId", fineId.toString(), "userEmail", email));
        try {
            @SuppressWarnings("unchecked")
            Map<String, Object> response = restTemplate.postForObject(
                    API_BASE + "/orders", new HttpEntity<>(body, headers), Map.class);
            Object id = response == null ? null : response.get("id");
            if (id == null) throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "Razorpay did not return an order ID");
            return id.toString();
        } catch (RestClientResponseException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "Could not create Razorpay order: " + ex.getStatusCode());
        }
    }

    public void verifySignature(String orderId, String paymentId, String signature) {
        requireCredentials();
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(keySecret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] expected = mac.doFinal((orderId + "|" + paymentId).getBytes(StandardCharsets.UTF_8));
            byte[] supplied = hexToBytes(signature);
            if (!MessageDigest.isEqual(expected, supplied)) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid Razorpay payment signature");
            }
        } catch (ResponseStatusException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to verify payment signature");
        }
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> fetchPayment(String paymentId) {
        requireCredentials();
        try {
            return restTemplate.exchange(API_BASE + "/payments/" + paymentId, HttpMethod.GET,
                    new HttpEntity<>(authHeaders()), Map.class).getBody();
        } catch (RestClientResponseException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "Could not confirm Razorpay payment status: " + ex.getStatusCode());
        }
    }


    @SuppressWarnings("unchecked")
    public Map<String, Object> capturePayment(String paymentId, long amountInPaise) {
        requireCredentials();
        HttpHeaders headers = authHeaders();
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("amount", amountInPaise);
        body.put("currency", "INR");
        try {
            return restTemplate.postForObject(API_BASE + "/payments/" + paymentId + "/capture",
                    new HttpEntity<>(body, headers), Map.class);
        } catch (RestClientResponseException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY,
                    "Razorpay could not capture the payment: " + ex.getStatusCode());
        }
    }

    private HttpHeaders authHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(keyId, keySecret);
        headers.setContentType(MediaType.APPLICATION_JSON);
        return headers;
    }

    private void requireCredentials() {
        if (keyId == null || keyId.isBlank() || keySecret == null || keySecret.isBlank()) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                    "Razorpay is not configured. Set RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET.");
        }
    }

    private byte[] hexToBytes(String hex) {
        if (hex == null || hex.length() != 64 || !hex.matches("[0-9a-fA-F]{64}")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid Razorpay payment signature format");
        }
        byte[] out = new byte[hex.length() / 2];
        for (int i = 0; i < hex.length(); i += 2) {
            out[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i + 1), 16));
        }
        return out;
    }
}

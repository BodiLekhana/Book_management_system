package controller;

import java.io.ByteArrayInputStream;
import java.security.Principal;
import java.util.List;
import java.util.Map;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import dto.RazorpayOrderResponse;
import dto.VerifyPaymentRequest;
import entity.Fine;
import service.FineService;

@RestController
@RequestMapping("/fines")
public class FineController {
    private final FineService service;
    public FineController(FineService service) { this.service = service; }

    @PostMapping("/create")
    @PreAuthorize("hasAnyRole('USER','ADMIN','SUPER_ADMIN')")
    public Fine createFine(@RequestParam String email, @RequestParam Long borrowId,
                           @RequestParam double amount, Principal principal, Authentication authentication) {
        boolean isUser = authentication.getAuthorities().stream()
                .anyMatch(authority -> "ROLE_USER".equals(authority.getAuthority()));
        // Borrow Service forwards the signed-in user's JWT when it generates a late-return fine.
        // A USER token may only create a fine against its own account; admins may create fines manually.
        if (isUser && (principal == null || !principal.getName().equalsIgnoreCase(email))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Users can only create fines for their own account");
        }
        return service.createFine(email, borrowId, amount);
    }

    @GetMapping("/my")
    @PreAuthorize("hasRole('USER')")
    public List<Fine> myFines(Principal principal) { return service.myFines(principal.getName()); }

    @GetMapping("/all")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN')")
    public List<Fine> allFines() { return service.allFines(); }

    @PostMapping("/payment/order/{id}")
    @PreAuthorize("hasRole('USER')")
    public RazorpayOrderResponse createPaymentOrder(@PathVariable Long id, Principal principal) {
        return service.createPaymentOrder(id, principal.getName());
    }

    @PostMapping("/payment/verify")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> verifyPayment(@RequestBody VerifyPaymentRequest request, Principal principal) {
        Fine fine = service.verifyPayment(request, principal.getName());
        return ResponseEntity.ok(Map.of("message", "Payment verified successfully", "fineId", fine.getId(), "paid", fine.isPaid()));
    }

    // This endpoint downloads a receipt; it does not perform or mark a payment.
    @GetMapping("/pay/{id}")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<InputStreamResource> downloadReceipt(@PathVariable Long id, Principal principal) {
        ByteArrayInputStream bis = service.receipt(id, principal.getName());
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=fine-receipt-" + id + ".pdf");
        return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF).body(new InputStreamResource(bis));
    }

    @GetMapping("/count")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    public long totalFines() { return service.totalFines(); }

    @GetMapping("/amount")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    public Double totalFineAmount() { return service.totalFineAmount(); }
}

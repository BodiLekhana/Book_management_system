package dto;

public class RazorpayOrderResponse {
    private final Long fineId;
    private final String keyId;
    private final String orderId;
    private final long amount;
    private final String currency;
    private final String userEmail;
    public RazorpayOrderResponse(Long fineId, String keyId, String orderId, long amount, String currency, String userEmail) {
        this.fineId = fineId; this.keyId = keyId; this.orderId = orderId; this.amount = amount; this.currency = currency; this.userEmail = userEmail;
    }
    public Long getFineId() { return fineId; }
    public String getKeyId() { return keyId; }
    public String getOrderId() { return orderId; }
    public long getAmount() { return amount; }
    public String getCurrency() { return currency; }
    public String getUserEmail() { return userEmail; }
}

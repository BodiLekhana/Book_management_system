import { Component, OnInit, ChangeDetectorRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { catchError, finalize, forkJoin, of, timeout } from 'rxjs';
import { BookService } from '../../../core/services/book.service';
import { BorrowService } from '../../../core/services/borrow.service';
import { NotificationService } from '../../../core/services/notification.service';
import { Book } from '../../../core/models/book.model';
import { BorrowRecord } from '../../../core/models/borrow-record.model';
import { LoadingComponent } from '../../../shared/loading/loading';

@Component({
  selector: 'app-user-books',
  standalone: true,
  imports: [CommonModule, FormsModule, LoadingComponent],
  styles: [`
    .catalog-page { background: #f5f7fb; min-height: 100%; }
    .catalog-hero { color: #fff; background: linear-gradient(120deg, #173b70 0%, #245ca4 58%, #3679c8 100%); box-shadow: 0 12px 28px rgba(27, 68, 120, .13); }
    .catalog-hero-icon { width: 56px; height: 56px; flex: 0 0 56px; display: grid; place-items: center; border-radius: 16px; background: rgba(255,255,255,.14); font-size: 1.6rem; }
    .catalog-eyebrow { letter-spacing: .12em; color: #d5e6ff; }
    .catalog-subtitle { color: #dce9fa; }
    .catalog-stat { min-width: 145px; background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.2); }
    .book-card { transition: transform .18s ease, box-shadow .18s ease; }
    .book-card:hover { transform: translateY(-3px); box-shadow: 0 1rem 2rem rgba(30, 55, 90, .10) !important; }
    .book-title { line-height: 1.35; min-height: 2.7em; }
    .borrowed-note { color: #176746; background: #eaf7f0; }
    .borrow-button { min-width: 112px; }
    @media (prefers-reduced-motion: reduce) { .book-card { transition: none; } }
  `],
  template: `
    <div class="container-fluid px-3 px-lg-4 py-4 catalog-page">
      <section class="catalog-hero rounded-4 p-4 p-lg-5 mb-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-4">
          <div class="d-flex align-items-start gap-3">
            <div class="catalog-hero-icon"><i class="bi bi-journals"></i></div>
            <div>
              <div class="text-uppercase small fw-semibold catalog-eyebrow mb-2">Library collection</div>
              <h2 class="fw-bold mb-2">Browse Books</h2>
              <p class="mb-0 catalog-subtitle">Discover your next read and manage your borrowing in one place.</p>
            </div>
          </div>
          <div class="catalog-stat rounded-4 px-4 py-3">
            <span class="d-block small catalog-subtitle">Books in catalog</span>
            <strong class="fs-3">{{ books.length }}</strong>
          </div>
        </div>
      </section>

      <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
          <h5 class="fw-bold mb-1">Explore the collection</h5>
          <p class="text-secondary small mb-0">Search by title, author, or category</p>
        </div>

        <div class="d-flex gap-2" style="max-width: 420px; width: 100%;">
          <div class="input-group">
            <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-secondary"></i></span>
            <input type="text" class="form-control border-start-0" placeholder="Search title or author..." [(ngModel)]="searchTerm" (ngModelChange)="applyFilter()">
          </div>
        </div>
      </div>

      <app-loading *ngIf="isLoading" message="Loading your library catalog..."></app-loading>

      <div *ngIf="!isLoading">
        <div *ngIf="loadError" class="alert alert-danger rounded-4">
          <i class="bi bi-exclamation-triangle me-2"></i>
          Unable to load the book catalog. Please refresh and try again.
        </div>
        <div *ngIf="filteredBooks.length === 0" class="text-center py-5 bg-white rounded-4 border">
          <i class="bi bi-inbox fs-1 text-secondary"></i>
          <p class="text-secondary mt-2">No books found matching your criteria.</p>
        </div>

        <div class="row g-4" *ngIf="filteredBooks.length > 0">
          <div class="col-12 col-md-6 col-lg-4 col-xl-3" *ngFor="let book of filteredBooks">
            <div class="card book-card h-100 border-0 shadow-sm rounded-4 bg-white position-relative d-flex flex-column">
              <div class="card-body p-4 d-flex flex-column">
                <div class="d-flex justify-content-between align-items-start mb-2">
                  <span class="badge bg-light text-secondary border text-uppercase px-3 py-2 rounded-pill small">{{ book.category }}</span>
                  <span class="badge rounded-pill px-3 py-2" [ngClass]="book.quantity > 0 ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'">
                    {{ book.quantity > 0 ? book.quantity + ' available' : 'Out of stock' }}
                  </span>
                </div>

                <h5 class="fw-bold card-title text-dark mb-2 book-title">{{ book.title }}</h5>
                <p class="card-subtitle text-secondary small mb-3"><i class="bi bi-person me-1"></i>by {{ book.author }}</p>
                <div *ngIf="hasActiveBorrow(book.id)" class="borrowed-note small rounded-3 px-3 py-2 mb-2">
                  <i class="bi bi-check-circle-fill me-2"></i>You already have this book borrowed
                </div>

                <div class="mt-auto pt-3 border-top d-flex justify-content-between align-items-center">
                  <div>
                    <span class="text-secondary small d-block">Price</span>
                    <span class="fw-bold text-dark fs-5">₹{{ book.price }}</span>
                  </div>

                  <button
                    class="btn rounded-3 px-3 py-2 fw-semibold borrow-button"
                    [ngClass]="hasActiveBorrow(book.id) ? 'btn-outline-secondary' : 'btn-primary'"
                    [disabled]="book.quantity <= 0 || borrowingId === book.id || hasActiveBorrow(book.id)"
                    (click)="borrowBook(book)">
                    <span *ngIf="borrowingId !== book.id && !hasActiveBorrow(book.id)"><i class="bi bi-bookmark-plus me-1"></i> Borrow</span>
                    <span *ngIf="hasActiveBorrow(book.id)"><i class="bi bi-check2-circle me-1"></i> Borrowed</span>
                    <span *ngIf="borrowingId === book.id && !hasActiveBorrow(book.id)" class="spinner-border spinner-border-sm" aria-label="Borrowing"></span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class UserBooksComponent implements OnInit {
  private bookService = inject(BookService);
  private borrowService = inject(BorrowService);
  private notificationService = inject(NotificationService);
  private cdr = inject(ChangeDetectorRef);

  loadError = false;

  books: Book[] = [];
  filteredBooks: Book[] = [];
  isLoading = true;
  searchTerm = '';
  borrowingId: number | null = null;
  private activeBorrowedBookIds = new Set<number>();

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks(): void {
    this.isLoading = true;
    this.loadError = false;

    forkJoin({
      books: this.bookService.getAllBooks().pipe(
        timeout(10000),
        catchError(() => {
          this.loadError = true;
          return of([] as Book[]);
        })
      ),
      myBorrows: this.borrowService.getMyBooks().pipe(
        timeout(10000),
        catchError(() => of([] as BorrowRecord[]))
      )
    }).pipe(
      finalize(() => {
        this.isLoading = false;
        this.cdr.detectChanges();
      })
    ).subscribe({
      next: ({ books, myBorrows }) => {
        this.books = Array.isArray(books) ? books : [];
        this.activeBorrowedBookIds = new Set(
          (Array.isArray(myBorrows) ? myBorrows : [])
            .filter(record => record && record.returned === false && Number.isFinite(Number(record.bookId)))
            .map(record => Number(record.bookId))
        );
        this.applyFilter();
        this.cdr.detectChanges();
      },
      error: () => {
        this.books = [];
        this.filteredBooks = [];
        this.loadError = true;
        this.cdr.detectChanges();
      }
    });
  }

  hasActiveBorrow(bookId: number | undefined): boolean {
    return bookId !== undefined && this.activeBorrowedBookIds.has(Number(bookId));
  }

  applyFilter(): void {
    if (!this.searchTerm.trim()) {
      this.filteredBooks = [...this.books];
      return;
    }
    const term = this.searchTerm.toLowerCase();
    this.filteredBooks = this.books.filter(b =>
      String(b.title ?? '').toLowerCase().includes(term) ||
      String(b.author ?? '').toLowerCase().includes(term) ||
      String(b.category ?? '').toLowerCase().includes(term)
    );
  }

  borrowBook(book: Book): void {
    if (!book.id) return;
    if (this.hasActiveBorrow(book.id) || book.quantity <= 0 || this.borrowingId !== null) return;
    this.borrowingId = book.id;

    this.borrowService.borrowBook(book.id).pipe(
      finalize(() => {
        this.borrowingId = null;
        this.cdr.detectChanges();
      })
    ).subscribe({
      next: () => {
        this.activeBorrowedBookIds.add(Number(book.id));
        this.applyFilter();
        this.notificationService.showSuccess(`Successfully borrowed "${book.title}"!`);
        this.cdr.detectChanges();
        this.loadBooks();
      },
      error: (err) => {
        const message = err?.error?.message || 'Unable to borrow this book. Please try again.';
        this.notificationService.showError(message);
        this.cdr.detectChanges();
      }
    });
  }
}

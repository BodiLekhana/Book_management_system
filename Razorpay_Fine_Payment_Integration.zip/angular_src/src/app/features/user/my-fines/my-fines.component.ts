import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { finalize } from 'rxjs';
import { FineService, RazorpayOrder } from '../../../core/services/fine.service';
import { NotificationService } from '../../../core/services/notification.service';
import { Fine } from '../../../core/models/fine.model';
import { LoadingComponent } from '../../../shared/loading/loading';

@Component({
  selector: 'app-my-fines',
  standalone: true,
  imports: [CommonModule, LoadingComponent],
  template: `
    <div class="container-fluid p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 class="fw-bold mb-1">My Fines</h2>
          <p class="text-secondary small mb-0">Securely pay outstanding fines with Razorpay</p>
        </div>
      </div>

      <div class="alert alert-info rounded-3" role="note">
        Payments are verified by the server. Your fine is marked paid only after Razorpay confirms a captured payment.
      </div>

      <app-loading *ngIf="isLoading" message="Fetching fine records..."></app-loading>

      <div *ngIf="!isLoading">
        <div *ngIf="errorMessage" class="alert alert-danger rounded-3">{{ errorMessage }}</div>
        <div *ngIf="fines.length === 0" class="text-center py-5 bg-white rounded-4 border">
          <i class="bi bi-shield-check fs-1 text-success"></i>
          <h5 class="fw-bold mt-2">No Fine Records</h5>
          <p class="text-secondary">You do not have any fine records on file.</p>
        </div>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden" *ngIf="fines.length > 0">
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th class="py-3 px-4">Fine ID</th>
                  <th class="py-3">Borrow ID</th>
                  <th class="py-3">Amount</th>
                  <th class="py-3">Status</th>
                  <th class="py-3 text-end px-4">Action</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let fine of fines">
                  <td class="px-4 fw-bold text-secondary">#{{ fine.id }}</td>
                  <td class="fw-semibold">Borrow Record #{{ fine.borrowId }}</td>
                  <td><span class="fw-bold" [class.text-danger]="!fine.paid" [class.text-success]="fine.paid">₹{{ fine.amount | number:'1.2-2' }}</span></td>
                  <td>
                    <span class="badge" [ngClass]="fine.paid ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'">
                      {{ fine.paid ? 'Paid' : 'Unpaid' }}
                    </span>
                  </td>
                  <td class="text-end px-4">
                    <button *ngIf="!fine.paid" class="btn btn-sm btn-success rounded-3 px-3"
                      [disabled]="payingId === fine.id" (click)="payFine(fine)">
                      <span *ngIf="payingId !== fine.id"><i class="bi bi-credit-card me-1"></i> Pay Now</span>
                      <span *ngIf="payingId === fine.id"><span class="spinner-border spinner-border-sm me-1"></span> Preparing...</span>
                    </button>
                    <button *ngIf="fine.paid" class="btn btn-sm btn-outline-success rounded-3 px-3"
                      [disabled]="receiptLoadingId === fine.id" (click)="downloadReceipt(fine)">
                      <span *ngIf="receiptLoadingId !== fine.id"><i class="bi bi-file-earmark-pdf me-1"></i> Download Receipt</span>
                      <span *ngIf="receiptLoadingId === fine.id"><span class="spinner-border spinner-border-sm me-1"></span> Downloading...</span>
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `
})
export class MyFinesComponent implements OnInit {
  private fineService = inject(FineService);
  private notificationService = inject(NotificationService);
  private cdr = inject(ChangeDetectorRef);

  fines: Fine[] = [];
  isLoading = true;
  payingId: number | null = null;
  receiptLoadingId: number | null = null;
  errorMessage = '';

  ngOnInit(): void { this.loadFines(); }

  loadFines(): void {
    this.isLoading = true;
    this.errorMessage = '';
    this.fineService.getMyFines().pipe(finalize(() => {
      this.isLoading = false;
      this.cdr.detectChanges();
    })).subscribe({
      next: data => { this.fines = Array.isArray(data) ? data : []; this.cdr.detectChanges(); },
      error: err => {
        console.error('Failed to load fines', err);
        this.fines = [];
        this.errorMessage = 'Unable to load your fines. Please try again.';
        this.cdr.detectChanges();
      }
    });
  }

  payFine(fine: Fine): void {
    if (!fine.id || fine.paid || this.payingId !== null) return;
    this.payingId = fine.id;
    this.cdr.detectChanges();
    this.fineService.createPaymentOrder(fine.id).subscribe({
      next: order => this.openRazorpayCheckout(fine, order),
      error: err => {
        console.error('Could not create payment order', err);
        this.payingId = null;
        this.notificationService.showError(this.apiError(err, 'Could not start payment. Please try again.'));
        this.cdr.detectChanges();
      }
    });
  }

  private async openRazorpayCheckout(fine: Fine, order: RazorpayOrder): Promise<void> {
    const loaded = await this.loadRazorpayScript();
    const RazorpayConstructor = (window as any).Razorpay;
    if (!loaded || !RazorpayConstructor) {
      this.payingId = null;
      this.notificationService.showError('Razorpay Checkout could not be loaded. Check your internet connection and try again.');
      this.cdr.detectChanges();
      return;
    }

    const checkout = new RazorpayConstructor({
      key: order.keyId,
      amount: order.amount,
      currency: order.currency,
      name: 'Library Management System',
      description: `Payment for fine #${fine.id}`,
      order_id: order.orderId,
      prefill: { email: order.userEmail },
      notes: { fineId: String(fine.id) },
      theme: { color: '#198754' },
      handler: (response: any) => {
        this.fineService.verifyPayment({
          fineId: fine.id!,
          razorpayOrderId: response.razorpay_order_id,
          razorpayPaymentId: response.razorpay_payment_id,
          razorpaySignature: response.razorpay_signature
        }).subscribe({
          next: result => {
            this.payingId = null;
            if (result.paid) {
              this.notificationService.showSuccess('Payment verified successfully. Your fine is now paid.');
              fine.paid = true;
              this.loadFines();
              this.downloadReceipt(fine);
            } else {
              this.notificationService.showError('Payment was received but is not yet confirmed as captured. Please refresh later.');
              this.loadFines();
            }
            this.cdr.detectChanges();
          },
          error: err => {
            this.payingId = null;
            console.error('Payment verification failed', err);
            this.notificationService.showError(this.apiError(err, 'Payment verification failed. Do not retry payment immediately; refresh your fines and check the status.'));
            this.loadFines();
            this.cdr.detectChanges();
          }
        });
      },
      modal: {
        ondismiss: () => {
          this.payingId = null;
          this.cdr.detectChanges();
        }
      }
    });

    checkout.on('payment.failed', (event: any) => {
      this.payingId = null;
      this.notificationService.showError(event?.error?.description || 'Payment failed. No fine status was changed.');
      this.cdr.detectChanges();
    });
    checkout.open();
  }

  downloadReceipt(fine: Fine): void {
    if (!fine.id || !fine.paid || this.receiptLoadingId !== null) return;
    this.receiptLoadingId = fine.id;
    this.fineService.downloadReceipt(fine.id).pipe(finalize(() => {
      this.receiptLoadingId = null;
      this.cdr.detectChanges();
    })).subscribe({
      next: blob => {
        const url = window.URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = `fine-receipt-${fine.id}.pdf`;
        document.body.appendChild(anchor);
        anchor.click();
        document.body.removeChild(anchor);
        window.URL.revokeObjectURL(url);
      },
      error: err => {
        console.error('Receipt download failed', err);
        this.notificationService.showError(this.apiError(err, 'Payment succeeded, but the receipt could not be downloaded. Use Download Receipt to try again.'));
      }
    });
  }

  private loadRazorpayScript(): Promise<boolean> {
    if ((window as any).Razorpay) return Promise.resolve(true);
    return new Promise(resolve => {
      const existing = document.querySelector<HTMLScriptElement>('script[data-razorpay-checkout]');
      if (existing) {
        existing.addEventListener('load', () => resolve(!!(window as any).Razorpay), { once: true });
        existing.addEventListener('error', () => resolve(false), { once: true });
        return;
      }
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.async = true;
      script.dataset['razorpayCheckout'] = 'true';
      script.onload = () => resolve(!!(window as any).Razorpay);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  }

  private apiError(error: any, fallback: string): string {
    return error?.error?.message || error?.error?.detail || fallback;
  }
}

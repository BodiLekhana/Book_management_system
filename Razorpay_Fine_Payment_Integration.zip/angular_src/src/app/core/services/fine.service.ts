import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Fine } from '../models/fine.model';

export interface RazorpayOrder {
  fineId: number;
  keyId: string;
  orderId: string;
  amount: number; // paise
  currency: string;
  userEmail: string;
}

export interface RazorpayVerification {
  fineId: number;
  razorpayOrderId: string;
  razorpayPaymentId: string;
  razorpaySignature: string;
}

@Injectable({ providedIn: 'root' })
export class FineService {
  private http = inject(HttpClient);
  private finesUrl = `${environment.apiUrl}/fines`;

  createFine(email: string, borrowId: number, amount: number): Observable<Fine> {
    const params = new HttpParams()
      .set('email', email)
      .set('borrowId', borrowId.toString())
      .set('amount', amount.toString());
    return this.http.post<Fine>(`${this.finesUrl}/create`, null, { params });
  }

  getMyFines(): Observable<Fine[]> {
    return this.http.get<Fine[]>(`${this.finesUrl}/my`);
  }

  getAllFines(): Observable<Fine[]> {
    return this.http.get<Fine[]>(`${this.finesUrl}/all`);
  }

  createPaymentOrder(fineId: number): Observable<RazorpayOrder> {
    return this.http.post<RazorpayOrder>(`${this.finesUrl}/payment/order/${fineId}`, {});
  }

  verifyPayment(payload: RazorpayVerification): Observable<{ message: string; fineId: number; paid: boolean }> {
    return this.http.post<{ message: string; fineId: number; paid: boolean }>(`${this.finesUrl}/payment/verify`, payload);
  }

  // Downloads the PDF receipt for a fine that has already been paid and verified.
  downloadReceipt(id: number): Observable<Blob> {
    return this.http.get(`${this.finesUrl}/pay/${id}`, { responseType: 'blob' });
  }

  /** @deprecated Use downloadReceipt; this endpoint never initiates payment. */
  payFine(id: number): Observable<Blob> {
    return this.downloadReceipt(id);
  }

  getTotalFines(): Observable<number> {
    return this.http.get<number>(`${this.finesUrl}/count`);
  }

  getTotalFineAmount(): Observable<number> {
    return this.http.get<number>(`${this.finesUrl}/amount`);
  }
}
